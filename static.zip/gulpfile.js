const fse = require('fs-extra')
const path = require('path')
const gulp = require('gulp')
const babel = require('gulp-babel')
const compressing = require('compressing')

/**
 * 复制模板文件
 */
function copyTemplate (cb) {
  try {
    const sourcePath = path.resolve(__dirname, './datav-template-src')
    const destPath = path.resolve(__dirname, './static/datav-template')
    fse.emptyDirSync(destPath)
    fse.copySync(sourcePath, destPath)
  } catch (error) {
    console.error('复制模板代码失败：', error)
  }
  cb()
}

/**
 * babel编译模板
 */
function compileTemplate (cb) {
  try {
    gulp.src('./static/datav-template/**/*.js', {
      ignore: './static/datav-template/lib/**/*.js'
    })
      .pipe(babel({
        configFile: './babel.template.config.js',
        babelrc: false
      }))
      .pipe(gulp.dest('./static/datav-template/'))
  } catch (error) {
    console.error('编译模板代码失败：', error)
  }
  cb()
}

/**
 * 复制模板到后台，下载
 */
function copyTemplate2Pro (cb) {
  try {
    const sourcePath = path.resolve(__dirname, './static/datav-template')
    const destPath = path.resolve(__dirname, '../../src/main/resources/datav-template')
    fse.emptyDirSync(destPath)
    fse.copySync(sourcePath, destPath)

    // 修改模板代码，dev ---> pro
    const mainFilePath = path.resolve(destPath, 'main.js')
    let mainCode = fse.readFileSync(mainFilePath, 'utf8')
    mainCode = mainCode.replace(/const\s*env\s*=\s*["'](dev|pro)["']/i, `const env = 'pro'`)
    fse.writeFileSync(mainFilePath, mainCode)
  } catch (error) {
    console.error('复制模板代码失败：', error)
  }
  cb()
}

function copyUpload2Pro (cb) {
  try {
    const sourcePath = path.resolve(__dirname, '../../upload')
    const destPath = path.resolve(__dirname, '../../src/main/resources/upload')
    fse.copySync(sourcePath, destPath)
    cb()
  } catch (error) {
    console.error('复制资源图片失败：', error)
    cb()
  }
}

/**
 * 编译生产模板
 */
function compileTemplatePro (cb) {
  try {
    gulp.src(path.resolve(__dirname, '../../src/main/resources/datav-template/**/*.js'), {
      ignore: path.resolve(__dirname, '../../src/main/resources/datav-template/lib/**/*.js')
    })
      .pipe(babel({
        configFile: './babel.template.config.js',
        babelrc: false
      }))
      .pipe(gulp.dest(path.resolve(__dirname, '../../src/main/resources/datav-template/')))
  } catch (error) {
    console.error('编译模板代码失败：', error)
  }
  cb()
}

/**
 * 压缩文件
 */
function compress (cb) {
  try {
    let sourPath = path.resolve(__dirname, '../../src/main/resources/dataV')
    let distPath = path.resolve(__dirname, '../../src/main/resources/dataV.zip')
    compressing.zip.compressDir(sourPath, distPath)
      .then(() => {
        cb()
      })
      .catch(error => {
        console.log(`压缩文件失败：${error.message}`)
        cb()
      })
  } catch (error) {
    console.log(`压缩文件失败：${error.message}`)
    cb()
  }
}

/**
 * 压缩文件
 */
function compressTemplate (cb) {
  try {
    let sourPath = path.resolve(__dirname, '../../src/main/resources/datav-template')
    let distPath = path.resolve(__dirname, '../../src/main/resources/datav-template.zip')
    compressing.zip.compressDir(sourPath, distPath)
      .then(() => {
        cb()
      })
      .catch(error => {
        console.log(`压缩文件失败：${error.message}`)
        cb()
      })
  } catch (error) {
    console.log(`压缩文件失败：${error.message}`)
    cb()
  }
}

function compressUpload (cb) {
  try {
    let sourPath = path.resolve(__dirname, '../../src/main/resources/upload')
    let distPath = path.resolve(__dirname, '../../src/main/resources/upload.zip')
    compressing.zip.compressDir(sourPath, distPath)
      .then(() => {
        cb()
      })
      .catch(error => {
        console.log(`压缩文件失败：${error.message}`)
        cb()
      })
  } catch (error) {
    console.log(`压缩文件失败：${error.message}`)
    cb()
  }
}

const buildTemplate = gulp.series(copyTemplate, compileTemplate, copyTemplate2Pro, copyUpload2Pro, compileTemplatePro, compress, compressTemplate, compressUpload)

gulp.task('compress', compress)

gulp.task('compressTemplate', compressTemplate)

gulp.task('buildTemplateHot', function () {
  buildTemplate()
  gulp.watch('./datav-template-src/**', buildTemplate)
})

gulp.task('buildTemplate', buildTemplate)

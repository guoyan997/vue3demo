/**
 * 作品的版本信息，用于检测后台编辑是否有更新发布
 * 如果publishDate < 后台数据库记录的发布期日，则后台有编辑更新过，刷新页面
 * workId - 作品id
 * publishDate - 最近发布日期
 * checkInterval - 检查更新的频率
 * checkUpdateApi - 检查更新的接口
 */
window.workId = "86ac0214-7940-4d71-9a39-68257cb2d6cb"
window.publishDate = "2019-03-06 21:02:41"
window.checkInterval = 60000
window.checkUpdateApi = "/dataV/work/checkUpdate?uuid=" + window.workId + "&publishDate=" + window.publishDate

import { ElementUIComponent } from './component'

/** Menu Item Group Component */
export declare class ElMenuItemGroup extends ElementUIComponent {
  /** Group title */
  title: string
}

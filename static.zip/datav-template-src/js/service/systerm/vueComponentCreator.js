// 创建vue组件

/**
  * @description Vue 组件对象构造器，将component对象组合成Vue组件对象
  * @param { Component } Component对象
  * @returns { Object } Vue组件对象
  */

// 注意：这里的路径是相对于main.js

define([
  'lib/lodash.min.js',
  'js/mixins/index.js'
], function (
  _,
  mixins
) {
  /**
   * @description 组件类型
   */
  const COMPONENT_TYPE = {
    'ECHART': 'ECHART',
    'PAGE': 'PAGE',
    'COMPONENT': 'COMPONENT' // 其他组件（非echart）
  }

  const vueComponentCreator = function (obj) {
    if (!obj && typeof obj !== 'object') {
      return {}
    }

    // 转换obj的函数字符串为函数
    // parseFunction(obj)

    const VueComponent = {}

    /**
      * 组件属性
      */
    VueComponent.props = obj.props
    // VueComponent.computed = obj.computed
    VueComponent.methods = obj.methods
    VueComponent.watch = obj.watch
    VueComponent.beforeCreate = obj.beforeCreate
    VueComponent.created = obj.created
    VueComponent.beforeMount = obj.beforeMount
    VueComponent.mounted = obj.mounted
    VueComponent.beforeUpdate = obj.beforeUpdate
    VueComponent.updated = obj.updated
    VueComponent.activated = obj.activated
    VueComponent.deactivated = obj.deactivated
    VueComponent.beforeDestroy = obj.beforeDestroy
    VueComponent.destroyed = obj.destroyed
    VueComponent.errorCaptured = obj.errorCaptured
    // VueComponent.mixins = obj.mixins
    VueComponent.name = obj.name

    /**
      * 混合属性
      */
    try {
      switch (obj.componentType) {
        case COMPONENT_TYPE.ECHART:
          VueComponent.mixins = _.concat([mixins.echart], obj.mixins)
          break
        case COMPONENT_TYPE.PAGE:
          VueComponent.mixins = _.concat([mixins.page], obj.mixins)
          break
        case COMPONENT_TYPE.COMPONENT:
          VueComponent.mixins = _.concat([mixins.comp], obj.mixins)
          break
        default:
          VueComponent.mixins = _.concat([], obj.mixins)
          break
      }
    } catch (error) {
      console.error(`处理组件混合失败：${error}`)
    }

    /**
      * 数据属性
      */
    try {
      const componentData = {}

      // 出场动画
      let _animateIn = ''
      if (obj.animateInList instanceof Array) {
        _animateIn = 'animated ' + obj.animateInList.join(' ')
      }
      componentData.animateIn = _animateIn

      // 子组件名称
      let _childrens = []
      for (let i = 0; i < obj.childrens.length; i++) {
        // 修改子组件层级，按照添加的先后顺序
        // obj.childrens[i] && obj.childrens[i].inlineStyle &&
        //   (obj.childrens[i].inlineStyle.zIndex = i)
        if (obj.childrens[i] && obj.childrens[i].inlineStyle && isNaN(Number(obj.childrens[i].inlineStyle.zIndex))) {
          obj.childrens[i].inlineStyle.zIndex = i
        }

        _childrens.push({
          name: obj.childrens[i].name + '-' + (i + 1),
          obj: obj.childrens[i]
        })
      }
      componentData.childrens = _childrens

      // 内联样式
      !isNaN(obj.width) && (obj.inlineStyle.width = obj.width + 'px')
      !isNaN(obj.height) && (obj.inlineStyle.height = obj.height + 'px')
      !isNaN(obj.top) && (obj.inlineStyle.top = obj.top + 'px')
      !isNaN(obj.left) && (obj.inlineStyle.left = obj.left + 'px')
      componentData.inlineStyle = obj.inlineStyle

      // 不同组件差异化处理
      switch (obj.componentType) {
        case COMPONENT_TYPE.ECHART:
          componentData.id = window._.uniqueId('chart-') // echarts组件ID
          componentData.echartsInstance = undefined // echarts实例
          componentData.inlineStyle.zIndex = 1 // 层级
          componentData.events = obj.events // 事件
          break
        case COMPONENT_TYPE.PAGE:
          componentData.states = obj.states // 页面状态变量
          componentData.stateTimer = {} // 定时器集合
          // 页面状态变量
          for (let state of obj.states) {
            componentData[`page_state_${state.name}`] = state.initValue
          }
          break
        default:
          break
      }

      // 组件自身数据
      // window.runDebugger && console.log(obj.data)
      componentData.self = obj.data
      componentData.self.outBlockId = obj.uuid
      // for (let x in obj.data) {
      //   componentData[x] = obj.data[x]
      // }

      // 扩展组件数据属性，不能直接引用componentData = obj.data
      // 为了响应式改变视图，改用计算属性来设置组件数据
      // _.assign(componentData, obj.data)

      VueComponent.data = function () {
        return componentData
      }

      // VueComponent.mixins.push({
      //   data () {
      //     return componentData
      //   }
      // })
    } catch (error) {
      console.error(`处理组件数据失败：${error}`)
    }

    /**
      * 计算属性，将组件数据转换成计算属性，以达到响应式改变
      */
    try {
      const computed = {}
      _.forOwn(obj.data, function (value, key) {
        computed[key] = function () {
          return this.self[key]
        }
      })
      _.assign(computed, obj.computed)
      VueComponent.computed = computed
    } catch (error) {
      console.error(`处理组件计算属性失败：${error}`)
    }

    /**
      * 模版属性
      */
    try {
      const pattern = /<[^//\s\n>]+/ // 查找模版最外层 <xxx
      let _template = ''
      if ('pointerEvents' in obj.data) {
        _template = obj.template.replace(pattern,
          `$& :style="[inlineStyle, {pointerEvents: pointerEvents}]" :class="[animateIn]"`)
      } else if (obj.name === 'DetailTable' || obj.name === 'MdxTable') {
        _template = obj.template.replace(pattern,
          `$& :style="[inlineStyle, outBorder]" :class="[animateIn]"`)
      } else {
        _template = obj.template.replace(pattern,
          `$& :style="[inlineStyle]" :class="[animateIn]"`)
      }
      VueComponent.template = _template
    } catch (error) {
      console.error(`处理组件模版失败：${error}`)
    }

    /**
      * 子组件
      */
    try {
      const _childrComponents = {}
      for (let i = 0; i < obj.childrens.length; i++) {
        const vueChild = vueComponentCreator(obj.childrens[i])
        // window.runDebugger && console.log('vueChild', vueChild)
        _childrComponents[vueChild.name + '-' + (i + 1)] = resolve => {
          resolve(vueChild)
        }
      }
      VueComponent.components = _childrComponents
    } catch (error) {
      console.error(`处理子组件失败：${error}`)
    }

    // if (VueComponent.name === 'Page') {
    //   window.runDebugger && console.log('BasicBarChart VueComponent', VueComponent)
    // }

    return VueComponent
  }

  return vueComponentCreator
})

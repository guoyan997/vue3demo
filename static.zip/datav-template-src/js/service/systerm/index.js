// 注意这里的路径是相对于main.js
define([
  'js/service/systerm/request.js',
  'js/service/systerm/formatNumber.js',
  'js/service/systerm/parse.js',
  'js/service/systerm/vueComponentCreator.js',
  'js/service/systerm/renderWork.js',
  'js/service/systerm/transApiData.js',
  'js/service/systerm/transDataToReportConfig.js',
  'js/service/systerm/transMdxToChartData.js',
  'js/service/systerm/weapon.js',
  'js/service/systerm/formatValue.js',
  'js/service/systerm/exportFile.js'
], function (
  request,
  formatNumber,
  parse,
  vueComponentCreator,
  renderWork,
  transApiData,
  transDataToReportConfig,
  transMdxToChartData,
  weapon,
  formatValue,
  exportFile
) {
  return {
    request: request,
    formatNumber: formatNumber,
    parse: parse,
    vueComponentCreator: vueComponentCreator,
    renderWork: renderWork,
    transApiData: transApiData,
    transDataToReportConfig: transDataToReportConfig,
    transMdxToChartData: transMdxToChartData,
    weapon: weapon,
    formatValue: formatValue,
    exportFile: exportFile
  }
})

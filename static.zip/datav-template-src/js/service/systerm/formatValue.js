/**
 * @description 约定格式验证
 */

define([], function () {
  const formatValue = (initStr, value) => {
    let outStr = initStr || null
    try {
      const $reg = /(\$\{.*?\})/g // 匹配 ${}

      let $Arr = outStr.match($reg)

      let finish$Arr = []// 存储将${}的内容处理完的数组
      if ($Arr.length > 0) {
        $Arr.forEach(item => {
          finish$Arr.push(deal$Str(item, value))
        })
      }
      let dex = -1
      if (finish$Arr.length > 0) {
        outStr = outStr.replace($reg, function (val, index) {
          dex++
          return finish$Arr[dex]
        })
      }
    } catch (err) {

    }

    // 处理完数值再将{name}{series}替换掉
    return outStr
  }
  function deal$Str ($str, value) { // 拿出${}里的内容进行处理
    const reg = /(\$\{)?(\})?/g // 匹配${}
    let contentStr = $str.replace(reg, '')// 去掉${},剩下中间的
    const reg2 = /\(.*\)/g// 匹配()
    let formatStr = contentStr.match(reg2)// 取括号里的
    let bracketIndex = contentStr.indexOf('(')
    let computationsStr = contentStr.substring(0, bracketIndex) // 取括号前面的，如果没有括号就全取

    if (!computationsStr || computationsStr === null) {
      computationsStr = contentStr
    }
    let computationStr = makeComputations(computationsStr, value)

    if (computationStr === undefined) {
      return $str
    }

    let dealFormatterStr = computationStr
    if (formatStr !== null) { // 如果有括号
      dealFormatterStr = dealFormatter(formatStr[0], computationStr)
    }

    let finalStr = dealFormatterStr

    return finalStr
  }
  function makeComputations (str, value) { // 处理括号前的运算
    let finalValue
    try {
      let initStr = str.replace('value', value)

      finalValue = eval('(' + initStr + ')')
    } catch (err) {
      console.err('括号前的格式有误')
    } finally {

    }
    return finalValue
  }
  function dealFormatter (str, value) { // 拿出${}里代表格式里的的括号内容进行处理
    let val = value
    const reg = /(\()?(\))?/g
    let midStr = str.replace(reg, '')// 去掉(),剩下中间的

    const regjing = /(#)/g
    let jingLength = midStr.match(regjing).length// 根据#号的数量还绝对需要保留的值的位数

    if (jingLength > 0) { // #号数大于0才去处理格式
      let showSepar = false// 是否显示千分位
      let precision// 保留几位小数
      // 1、 先处理小数点 查找.后面有几个#就是保留几位
      let pointIndex = midStr.indexOf('.')
      if (pointIndex > -1) {
        let tailStr = midStr.split('.')

        let tailLength = tailStr[1].match(regjing).length// .号后面的#号数量代表取多少位

        // 获得取数位后对值进行处理

        // let v2Num = Math.pow(10, tailLength)
        // val = formatNumber(value, tailLength, '', false)

        precision = tailLength
      }
      // 2、如果有#号但没有点的时候就保留整数
      if (pointIndex === -1 && jingLength > 0) {
        precision = 0
      }
      // 3、处理千分位
      if (jingLength > 2) { // ##号数量大于等于三个且有逗号的时候才会有千分位
        let dotIndex = midStr.indexOf(',')
        if (dotIndex > -1) {
          showSepar = true
          // val = formatNumber(val)
        }
      }
      val = formatNumber(value, precision, '', showSepar)
    }
    return val
  }
  /**
* @description 格式化数据
*/
  function formatNumber (num, precision, separator, showSepar = true) {
    let parts
    // 判断是否为数字
    if (!isNaN(parseFloat(num)) && isFinite(num)) {
      // 把类似 .5, 5. 之类的数据转化成0.5, 5, 为数据精度处理做准, 至于为什么
      // 不在判断中直接写 if (!isNaN(num = parseFloat(num)) && isFinite(num))
      // 是因为parseFloat有一个奇怪的精度问题, 比如 parseFloat(12312312.1234567119)
      // 的值变成了 12312312.123456713
      num = Number(num)
      // 处理小数点位数
      num = (typeof precision !== 'undefined' ? num.toFixed(precision) : num).toString()
      // 分离数字的小数部分和整数部分
      parts = num.split('.')
      if (showSepar) {
        // 整数部分加[separator]分隔, 借用一个著名的正则表达式
        parts[0] = parts[0].toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1' + (separator || ','))
      }
      return parts.join('.')
    } else {
      return num
    }
  }
  return formatValue
})
// 报错内容  括号内的内容 匹配不上

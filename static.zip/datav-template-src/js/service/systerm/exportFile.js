define([
  'lib/axios.min.js',
  'lib/html2canvas.min.js',
  'js/service/systerm/parse.js',
  'js/service/systerm/transDataToReportConfig.js',
  'js/service/systerm/transDataOptionListToSortList.js'
], function (
  axios,
  html2canvas,
  parse,
  transDataToReportConfig,
  transDataOptionListToSortList
) {
  const dataURItoBlob = function (dataURI) { // base64转buffer
    var byteString = atob(dataURI.split(',')[1])
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]
    var ab = new ArrayBuffer(byteString.length)
    var ia = new Uint8Array(ab)
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i)
    }
    return new Blob([ab], { type: mimeString })
  }
  const exportFile = (fileType, pageId, vueObj) => {
    let node = document.getElementsByClassName('work__page__content')[0]
    html2canvas(node, {
      scrollY: 0,
      scrollX: 0,
      useCORS: true,
      backgroundColor: null
    }).then(canvas => {
      // 转成图片，生成图片地址
      const imgUrl = canvas.toDataURL('image/png')
      const fd = new FormData()
      const blob = dataURItoBlob(imgUrl)
      fd.append('file', blob, Date.now() + '.png')
      fd.append('fileType', fileType)
      let workObj = {}
      if (vueObj.runMode === 'preview') {
        const workString = localStorage.getItem('work')
        if (typeof workString === 'string') {
          workObj = parse(workString)
        }
      } else if (vueObj.runMode === 'publish') {
        workObj = window.work
      }
      const pageIndex = workObj.childrens.findIndex(pages => pages.uuid === pageId)
      const reportConfigList = []
      let fileName = workObj.nameCN
      if (pageIndex > -1) {
        const page = workObj.childrens[pageIndex]
        fileName = fileName + '_' + page.nameCN
        const blockList = page.childrens
        for (let block of blockList) {
          const comp = block.childrens[0]
          if (comp.data.schema) { // 对于使用模型的组件
            let sortDtos = []
            if (comp.name === 'DetailTable' || comp.name === 'MdxTable') {
              sortDtos = comp.data.schema.sortList
            } else {
              sortDtos = transDataOptionListToSortList(comp.data.schema.dataOptionList, comp.name)
            }
            const reportConfig = transDataToReportConfig(comp.data.schema.dataOptionList, comp.name, {
              sortDtos: sortDtos,
              filter: comp.data.schema.filter,
              assemblyType: comp.data.schema.assemblyType,
              ifShowNull: '1'
            }, comp.data.aggregation)
            reportConfigList.push({ name: block.nameCN, schemaName: comp.data.schema.name, reportConfig })
          }
        }
      }

      fd.append('QueryRequestList', JSON.stringify(reportConfigList))
      fd.append('fileName', fileName)
      let url = '/work/generateFile'
      let exportUrl = '/work/exportFile'
      let startUrl = ''
      if ($global.onlineConfig && $global.onlineConfig.apiHost) {
        startUrl = $global.onlineConfig.apiHost
      } else {
        const hostUrl = $global.onlineConfig.defaultHost
        startUrl = hostUrl.length > 1 ? hostUrl.substring(0, hostUrl.length - 1) : '.'
      }
      url = startUrl + url
      exportUrl = startUrl + exportUrl
      axios({
        method: 'post',
        url: url,
        data: fd,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(response => {
        const result = response.data
        if (result.__statusCode === '1') {
          const fileName = result.data
          const urlString = exportUrl + '?fileName=' + encodeURIComponent(fileName)
          window.open(urlString, '_blank')
        } else {
          vueObj.$message({
            type: 'error',
            message: '文件导出失败，请稍后重试~'
          })
        }
      }).catch(function (error) {
        vueObj.$message({
          type: 'error',
          message: '文件导出失败，请稍后重试~'
        })
        console.error(`获取数据失败：${error}`)
      })
    })
  }
  return exportFile
})

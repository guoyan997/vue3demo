define([
  'js/service/systerm/weapon.js'
], function (
  weapon
) {
  const transDataToReportConfig = (dataOptionList, compName) => {
    let meaSortList = []
    let dimSortList = []
    let sortList = []
    const mesIndex = dataOptionList.findIndex(item => item.type === 'M')
    let rowDimLength = 0
    dataOptionList.map(item => {
      if (item.type !== 'M') {
        rowDimLength = rowDimLength + item.list.length
      }
    })
    if (mesIndex > -1) {
      for (let i = 0; i < dataOptionList[mesIndex].list.length; i++) {
        const data = dataOptionList[mesIndex].list[i]
        if (data.sortValue !== 'NOR') {
          const sortDto = {
            columnDataType: '0',
            parameter: data.value,
            orderRule: data.sortValue,
            sortType: 'InGroupSum',
            xNum: rowDimLength + i
          }
          meaSortList.push(sortDto)
        }
      }
    }
    // X轴参与排序，获取维度排序列表
    /**
     * 这里柱图是第一行为参与排序的行，其他的图形不一定是第一行，要根据不同的图形组件进行调整
     */
    for (let i = 0; i < dataOptionList[0].list.length; i++) {
      const data = dataOptionList[0].list[i]
      if (data.sortValue !== 'NOR') {
        const sortDto = {
          columnDataType: '1',
          parameter: data.value,
          orderRule: data.sortValue,
          sortType: 'InGroupDim',
          xNum: i
        }
        dimSortList.push(sortDto)
      }
    }
    meaSortList = meaSortList.sort(weapon.compareSort('xNum'))
    dimSortList = dimSortList.sort(weapon.compareSort('xNum'))
    if (meaSortList.length > 0) {
      sortList = [meaSortList[0]]
    } else {
      sortList = dimSortList
    }
    return sortList
  }
  return transDataToReportConfig
})

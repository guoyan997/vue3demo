// 渲染作品
// renderWork，global要在renderWork执行前挂载
// 注意：这里的路径是相对于main.js
define([
  'vue',
  'lib/vue-router',
  'lib/axios.min.js',
  'js/constant/index.js',
  'js/service/systerm/vueComponentCreator.js',
  'js/service/systerm/parse.js',
  'js/service/systerm/request.js',
  'ELEMENT'
], function (
  Vue,
  VueRouter,
  axios,
  constant,
  vueComponentCreator,
  parse,
  request,
  ELEMENT
) {
  ELEMENT.install(Vue)// 注册Element给vue全局
  Vue.config.productionTip = false
  Vue.prototype.$eventHub = new Vue({}) // Vue事件总线
  Vue.prototype.$http = axios
  var PAGE_EVENT = constant.PAGE_EVENT

  var renderWork = function (work, startPageIndex = 0, runMode = 'preview') {
    if (!work && runMode === 'preview') { // 如果作品不存在
      alert('请重新点击作品预览按钮进行查看！')
      return
    }
    if (!work && runMode === 'public') { // 如果作品不存在
      alert('请先发布作品后再进行查看！')
      return
    }
    if (typeof work === 'string') {
      work = parse(work)
    } else if (work.checkUpDateInterval && work.checkUpDateInterval > 0) {
      // 检查作品是否更新了
      setInterval(function () {
        checkUpdate()
      }, work.checkUpDateInterval * 60000)
    }
    // 初始化作品状态
    window.runDebugger && console.log('preview renderWork work=', work)

    // 更新背景图host和接口host，work-template中放在renderWork中执行
    if (work.onlineConfig.apiHost) {
      $global.onlineConfig.apiHost = work.onlineConfig.apiHost
      const newData = work.onlineConfig.apiHost
      if (newData.substring((newData.length - 1), newData.length) === '/') {
        $global.onlineConfig.apiHost = newData.substring(0, newData.length - 1)
      } else {
        $global.onlineConfig.apiHost = newData
      }
    }
    if (work.onlineConfig.sourceHost) {
      $global.onlineConfig.sourceHost = work.onlineConfig.sourceHost
    }
    // $global.onlineConfig.defaultSourceHost = work.onlineConfig.defaultSourceHost

    // 兼容以往作品-->
    if (!work.onlineConfig) {
      work.onlineConfig = {
        apiHost: '',
        sourcrHost: ''
      }
    }
    if (!work.data.workStyle) {
      work.data.workStyle = {
        backgroundColor: '', // 背景色
        backgroundImage: '', // 背景图片
        backgroundSize: '100% 100%'
      }
    }
    if (!work.data.workValueStyle) {
      work.data.workValueStyle = {
        width: 1920,
        height: 1080
      }
    }
    work.methods = {
      // 处理px单位的样式
      pxStyle: function (obj) {
        var objStyle = {}
        for (var key in obj) {
          // 只遍历对象自身的属性，而不包含继承于原型链上的属性
          if (obj.hasOwnProperty(key) === true) {
            objStyle[key] = obj[key] ? obj[key] + 'px' : '0'
          }
        }
        return objStyle
      },
      /**
       * @description 设置页面缩放
       */
      setPageViewerScale: function (that) {
        try {
          const winwidth = document.documentElement.clientWidth
          const winHeight = document.documentElement.clientHeight
          window.runDebugger && console.log('work.js this.workStyle=', this.workStyle)
          window.runDebugger && console.log('work.js this.$data.workStyle=', this.$data.workStyle)
          const widthScale = winwidth / that.workValueStyle.width * 100
          const heightScale = winHeight / that.workValueStyle.height * 100
          window.widthScale = widthScale / 100
          window.heightScale = heightScale / 100
          that.workStyle['transform-origin'] = `0 0`
          that.workStyle.transform = `scale(${widthScale / 100}, ${heightScale / 100})`
          // that.workStyle.transform = `scale(${100 / 100}, ${100 / 100})`

          // 触发WINDOW_RESIZE，iframe监听
          // 需要放在 window.widthSacle window.heightSacle 改变之后
          // 因为iframe的缩放依赖于这两个值
          this.$eventHub.$emit($global.WorkEvent.WINDOW_RESIZE)
        } catch (error) {
          console.error(`设置页面缩放失败：${error.message}`)
        }
      }
    }

    // work.template = `
    // <div id="app" class="work" :style="[workStyle, pxStyle(workValueStyle)]">
    //   <router-view />
    //   <audio :src="bgmUrl" controls autoplay loop
    //   :style="[bgmStyle.style]">
    //     您的浏览器不支持 audio 元素。
    //   </audio>
    // </div>
    // `
    if (!work.data.hasOwnProperty('autoScale')) {
      work.data.autoScale = true
    }
    work.routerSet.routerTipImg = 'img/resource/router-tip-left.png' // 修正路由图片路径

    for (let page of work.childrens) {
      page.width = ''
      page.height = '100%'
      page.inlineStyle.width = '100%'
      page.inlineStyle.height = '100%'
      if (!page.inlineStyle.backgroundColor) {
        page.inlineStyle.backgroundColor = ''
      }

      // 修正自动切换页面的配置 nextComponent——>nextPage
      if (!page.data.hasOwnProperty('nextPageId')) {
        // 没有播放控制项的旧作品
        if (page.nextPageId) {
          page.data.nextPageId = page.nextPageId
        } else if (page.nextComponentId) {
          page.data.nextPageId = page.nextComponentId
        } else {
          page.data.nextPageId = ''
        }
      }
      if (!page.data.hasOwnProperty('nextPageTime')) {
        if (page.nextPageTime) {
          page.data.nextPageTime = page.nextPageTime
        } else if (page.nextComponentTime) {
          page.data.nextPageTime = page.nextComponentTime
        } else {
          page.data.nextPageTime = ''
        }
      }
    }
    // <--兼容以往作品

    // 设置work背景
    let imgUrl = ''
    let patt = /^(http|\/\/)/ // 匹配字段以http开头或以//开头
    window.runDebugger && console.log('before work.data.workStyle=', work.data.workStyle)
    if (work.data.workStyle.backgroundImage && !patt.test(work.data.workStyle.backgroundImage)) {
      if ($global && $global.onlineConfig && $global.onlineConfig.sourceHost) {
        // 拼接host和图片路径
        imgUrl = 'url(' + $global.onlineConfig.sourceHost + work.data.workStyle.backgroundImage + ')'
      } else {
        imgUrl = 'url(' + $global.onlineConfig.defaultSourceHost + work.data.workStyle.backgroundImage + ')'
      }
    }
    work.data.workStyle.backgroundImage = imgUrl
    window.runDebugger && console.log('after work.data.workStyle=', work.data.workStyle)

    $global.workStyle = work.data.workStyle // pageMixin.js中处理切换页面闪烁问题
    // 将路由设置存到global
    $global.routerSet = work.routerSet

    $global.pageTruning = work.data.pageTruning

    $global.fontFamily = work.inlineStyle.fontFamily // 设置字体

    // 先取消自动全屏，退出全屏时会刷新页面
    if (work.data.fullScreenSet) {
      $global.fullScreenSet = work.data.fullScreenSet // 全屏配置存到global
      // if (work.data.fullScreenSet.openFullScreen === true
      //   && work.data.fullScreenSet.autoFullScreen === true) {
      //   fullScreen()
      // }
    }

    if (work.data.playSet) {
      $global.playSet = work.data.playSet // 播放配置存到global
    }

    if (work.routerSet.openRouterBtns && work.routerSet.routerType === 'dynamic') {
      // 请求路由数据 赋值给global和work
      try {
        const method = work.routerSet.dynamicRouterSet.method
        let url = work.routerSet.dynamicRouterSet.url
        window.runDebugger && console.log('$global=', $global)
        if ($global.onlineConfig.apiHost) {
          url = $global.onlineConfig.apiHost + url
        }
        // let paramsCopy = _.cloneDeep(this.dynamicRouterSet.params) // 拷贝
        let params = work.routerSet.dynamicRouterSet.params
        request(url, method, params).then(response => {
          // 返回的是字符串，要尝试将字符串转换成对象
          if (typeof response.data === 'string') {
            response.data = eval('(' + response.data + ')')
          }
          let result = response.data[work.routerSet.dynamicRouterSet.apiDataKey] || []
          let arr = []
          for (let dataItem of result) {
            let obj = {}
            obj.name = dataItem[work.routerSet.dynamicRouterSet.nameStr]
            obj.pageId = ''
            for (let page of work.childrens) {
              if (dataItem[work.routerSet.dynamicRouterSet.valueStr] === page.nameCN) {
                obj.pageId = page.uuid
                break
              }
            }
            if (!obj.pageId) {
              // 没有找到nameCN对应的page
              window.runDebugger && console.log('没有找到nameCN为' + dataItem[work.routerSet.dynamicRouterSet.valueStr] + '的page')
            }
            arr.push(obj)
          }
          work.routerSet.dynamicRouterSet.apiData = arr
          $global.routerSet.dynamicRouterSet.apiData = arr
        }).catch(error => {
          console.error('====== 请求接口失败 ======', error)
        })
      } catch (error) {
        console.error(`请求接口失败：${error}`)
      }
    }

    if (work.data._states_ && work.data._states_.length > 0) {
      for (let state of work.data._states_) {
        $global.state.work[state.name] = state.initValue
      }
    }
    window.runDebugger && console.log('after $global=', $global)

    Vue.use(VueRouter)

    let routes = []
    if (work.childrens.length > 0) {
      for (let page of work.childrens) {
        page.data.uuid = page.uuid // 用于路由按钮
        routes.push({
          path: '/' + page.uuid,
          name: page.uuid,
          component: function (resolve, reject) {
            // 页面跳转
            // window.runDebugger && console.log('page=', page)
            window.runDebugger && console.log('page.data.nextPageId=', page.data.nextPageId)
            if (page.data.nextPageId) {
              // 确保下一页存在
              for (let nextPage of work.childrens) {
                if (page.data.nextPageId === nextPage.uuid && page.data.nextPageTime) {
                  page.beforeCreate = function () {
                    page.data.timer = setTimeout(() => {
                      this.$router.push(page.data.nextPageId)
                    }, page.data.nextPageTime * 1000)
                  }
                  break
                }
              }
            }
            page.data.runMode = runMode
            for (let block of page.childrens) {
              block.data.runMode = runMode
              if (block.childrens.length > 0) {
                block.childrens[0].data.runMode = runMode
              }
            }
            resolve(vueComponentCreator(page))
          }
        })
      }
      // 单独抽离出某一个页面时
      let currentPageIndex = startPageIndex
      const urlIndex = window.location.href.indexOf('#/')
      const pageId = window.location.href.substring(urlIndex + 2, window.location.href.length)
      const pageIdList = []
      // 判断pageId的顺序
      for (let page of work.childrens) {
        pageIdList.push(page.uuid)
      }
      const find = pageIdList.findIndex(uuid => uuid === pageId)
      if (find > -1) {
        currentPageIndex = find
      }
      routes.unshift({
        path: '/',
        name: 'home',
        redirect: '/' + work.childrens[currentPageIndex].uuid
      })
    }
    window.runDebugger && console.log('routes', routes)
    // 将组件之间的联动和下钻关系剥离出来，放到全局使用
    for (let page of work.childrens) {
      for (let block of page.childrens) {
        const comp = block.childrens[0]
        if (comp && comp.data && comp.data.action) {
          for (let relation of comp.data.action.itemList) {
            if (relation.triggerEventValue === 'relate') {
              for (let tar of relation.triggerTargetValue) {
                $global.actionRelation.relationTargetList.push(tar)
              }
            }
          }
          if (comp.data.action.selfDetail) {
            $global.actionRelation.selfDetailList.push(comp.data.blockId)
          }
        }
      }
    }
    // 去重
    $global.actionRelation.relationTargetList = Array.from(new Set($global.actionRelation.relationTargetList))
    $global.actionRelation.selfDetailList = Array.from(new Set($global.actionRelation.selfDetailList))

    const router = new VueRouter({
      routes: routes
    })
    /* eslint-disable no-new */
    new Vue({
      el: '#app',
      // template: '<work></work>',
      template: work.template,
      router,
      created () {
        // 缩放页面
        window.runDebugger && console.log('this.$data=', this.$data)
        let that = this
        if (work.data.autoScale) {
          window.runDebugger && console.log('触发缩放')
          this.setPageViewerScale(this)
          var resizeTimer = null
          window.onresize = function () {
            window.runDebugger && console.log('触发缩放')
            if (resizeTimer) {
              clearTimeout(resizeTimer)
            }
            resizeTimer = setTimeout(function () {
              that.setPageViewerScale(that)
              window.runDebugger && console.log('that.$data=', that.$data)
              window.runDebugger && console.log('that.workStyle=', that.workStyle)
              that.$forceUpdate()
            }, 500)
          }
        }

        if (work.stateTimer) {
          for (let x in work.stateTimer) {
            clearInterval(work.stateTimer[x])
          }
        }
        work.stateTimer = {}

        if (work.data._states_ && work.data._states_.length > 0) {
          for (let state of work.data._states_) {
            if (state.changeType === 'timer') {
              const valueList = state.values.split(',')
              window.runDebugger && console.log('valueList=', valueList)
              work[`work_state_${state.name}`] = valueList[0]

              if (valueList.length > 1) {
                work.stateTimer[`work_state_${state.name}`] = setInterval(() => {
                  let currentIndex = valueList.indexOf(work[`work_state_${state.name}`]) // 记住切换到哪个索引了
                  const index = (++currentIndex) % valueList.length
                  work[`work_state_${state.name}`] = valueList[index]

                  $global.state.work[state.name] = work[`work_state_${state.name}`]
                  this.$eventHub.$emit(PAGE_EVENT.CHANGE_WORK_STATE + '_' + state.name)
                }, state.changeInterval)
              }
            }
          }
        }
        this.$router.push('/')
      },
      methods: work.methods,
      data: work.data,
      computed: work.computed
      // component: {
      //   work
      // }
    })

    /**
     * @description 检查作品是否更新
     */
    function checkUpdate () {
      try {
        let checkUpdateApi = window.checkUpdateApi
        axios.get(checkUpdateApi).then(response => {
          // response.data
          window.runDebugger && console.log('检查更新response=', response)
          if (response.data === true) {
            // 更新了
            location.reload(true) // 刷新页面且绕过缓存
          }
        }).catch(error => {
          console.error('====== 检查作品是否更新，失败 ======', error)
        })
      } catch (error) {
        console.error('====== 检查作品是否更新，失败 ======', error)
      }
    }

    /**
     * @description 全屏
     */
    function fullScreen () {
      window.runDebugger && console.log('执行fullScreen')
      // 判断当前是否为全屏
      if (document.isFullScreen || document.mozIsFullScreen || document.webkitIsFullScreen) {
        return
      }
      window.runDebugger && console.log('当前不是全屏')
      var dom = document.documentElement
      var openList = ['requestFullscreen', 'mozRequestFullScreen', 'webkitRequestFullScreen', 'msRequestFullscreen']
      var fn = void 0
      fn = window._.find(openList, function (n) {
        return Boolean(dom[n])
      })
      fn && dom[fn]()
    }
  }

  window.Vue = Vue

  return renderWork
})

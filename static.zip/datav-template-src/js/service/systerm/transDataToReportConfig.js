define(['lib/lodash.min.js'], function (_) {
  // 将dataOptionList数据转化为后端需要的格式
  const transDataToReportConfig = (dataOptionList, compName, option = { filter: { filterGroup: [], detailFilter: [], relationFilter: [], linkFilter: [], selfFilter: [] }, sortDtos: [], assemblyType: 'dv_chart', ifShowNull: '0' }, aggregation = { measureList: [], dimensionList: [] }) => {
    // function mergeDim (list) {
    //   let dimList = list
    //   // 合并维度下的levels数组
    //   for (let item of list) {
    //     for (let i = 0; i < dimList.length; i++) {
    //       if (item.dimensionName === dimList[i].dimensionName) {
    //         item.levels = [...item.levels, ...dimList[i].levels]
    //       }
    //     }
    //   }
    //   // 两次去重，删除不必要的数据
    //   const firstlist = unique(list, 'dimensionName')
    //   for (let dim of firstlist) {
    //     dim.levels = unique(dim.levels, 'levelName')
    //   }
    //   return firstlist
    // }
    // function unique (arr, key) {
    //   const res = new Map()
    //   return arr.filter((arr) => !res.has(arr[key]) && res.set(arr[key], 1))
    // }
    // 汇总过滤需要添加聚合标志
    function aggregationFlag (filterGroup) {
      const dataList = _.cloneDeep(filterGroup)
      for (let filterRow of dataList) {
        for (let item of filterRow.filters) {
          if (item.aggregator) {
            item.parameter = item.parameter + '_' + item.aggregator
          }
        }
      }
      return dataList
    }
    const relationFilter = option.filter.relationFilter ? option.filter.relationFilter : []
    const linkFilter = option.filter.linkFilter ? option.filter.linkFilter : []
    const selfFilter = option.filter.selfFilter ? option.filter.selfFilter : []
    const paramFilter = [...relationFilter, ...linkFilter, ...selfFilter]
    const reportConfig = {
      measures: [], // 存放度量列表
      columnDimensions: [], // 存放列维数据
      rowDimensions: [], // 存放行维数据
      filterList: { // 一个是结果过滤，一个是明细过滤
        resultFilter: aggregationFlag(option.filter.filterGroup),
        detailFilter: option.filter.detailFilter,
        paramFilter: paramFilter
      }, // 存放过滤条件集合
      sortDtos: option.sortDtos, // 排序对象
      subsetDto: option.subsetDto, // 分页对象
      ifShowNull: option.ifShowNull, // 是否显示空行
      isTotal: '0', // 是否合计
      subtotalList: [], // 小计的集合
      assemblyType: option.assemblyType // 区分是表格还是图形组件
    }
    // 先获取度量列表
    const measures = []
    const rowDimensions = []
    const columnDimensions = []
    const detailReportDtos = []
    for (let data of dataOptionList) {
      if (data.type === 'M') {
        // 从度量列表里获取数据
        for (let item of data.list) {
          // const columnDataType = item.columnDataType ? item.columnDataType : '0'
          const colType = item.columnDataType ? item.columnDataType : '0'
          const findM = aggregation.measureList.findIndex(mea => mea.value === item.value)
          const findD = aggregation.dimensionList.findIndex(dim => dim.value === item.value) // 如果是维度拖拽到度量列表上
          if (findM > -1) {
            const meaObj = aggregation.measureList[findM]
            // 放入聚合表达式
            measures.push({
              columnDataType: '0', // 如果是聚合，0表示聚合表达式
              colType,
              measureCaption: meaObj.name,
              measureName: meaObj.value,
              ifAggregateExpress: true,
              aggregateListGroupDtoList: meaObj.conditionList
            })
          } else if (findD > -1) {
            const meaObj = aggregation.dimensionList[findD]
            const aggregator = meaObj.aggregator === null ? 'count' : item.aggregator
            // 放入聚合表达式
            measures.push({
              aggregator,
              columnDataType: meaObj.resultType === 'number' ? '2' : '1',
              colType,
              measureCaption: meaObj.name,
              measureName: meaObj.value + '_' + aggregator,
              ifAggregateExpress: true,
              aggregateListGroupDtoList: meaObj.conditionList,
              resultType: meaObj.resultType || ''
            })
          } else {
            let aggregator = item.aggregator === null ? 'sum' : item.aggregator
            if (aggregator === 'znzb') {
              aggregator = 'mProportion'
            }
            // 这里要排除同名字段的干扰
            let value = item.value
            if (value.indexOf('-rep') > -1) {
              value = value.substring(0, value.indexOf('-rep'))
            }
            const thbOption = item.thbOption ? item.thbOption : { timeField: '', timePeriod: '' }
            measures.push({
              measureName: value + '_' + aggregator,
              measureCaption: item.name,
              aggregator,
              columnDataType: '0',
              colType,
              timeField: thbOption.timeField, // 同环比用到的时间字段
              timePeriod: thbOption.timePeriod, // 同环比用到的时间粒度
              levelName: item.levelName || ''
            })
          }
        }
      } else if (data.type === 'RD' || data.type === 'CD' || data.type === 'GEO') {
        for (let item of data.list) {
          const obj = {}
          // obj.dimensionName = item.level === '1' ? item.value : item.pId
          // obj.dimensionCaption = item.level === '1' ? item.name : item.pName
          obj.dimensionName = item.value
          obj.dimensionCaption = item.name
          obj.levels = [{ levelName: item.value, levelCaption: item.name, analysisDimType: data.subType, colType: item.name }]
          const findD = aggregation.dimensionList.findIndex(dim => dim.value === item.value)
          if (findD > -1) {
            const dimObj = aggregation.dimensionList[findD]
            obj.ifAggregateExpress = true
            obj.aggregateListGroupDtoList = dimObj.conditionList
          }
          // 分别对应到行维和列维的列表中
          if (data.type === 'RD' || data.type === 'GEO') {
            rowDimensions.push(obj)
          } else if (data.type === 'CD') {
            columnDimensions.push(obj)
          }
        }
      } else if (data.type === 'DM') {
        for (let item of data.list) {
          const obj = {}
          // obj.dimensionName = item.level === '1' ? item.value : item.pId
          // obj.dimensionCaption = item.level === '1' ? item.name : item.pName
          // obj.levels = [{ levelName: item.value, levelCaption: item.name, analysisDimType: data.subType, colType: item.name }]
          obj.name = item.value
          obj.caption = item.name
          detailReportDtos.push(obj)
        }
      }
    }
    reportConfig.measures = measures
    // reportConfig.rowDimensions = mergeDim(rowDimensions)
    // reportConfig.columnDimensions = mergeDim(columnDimensions)
    reportConfig.rowDimensions = rowDimensions
    reportConfig.columnDimensions = columnDimensions
    reportConfig.detailReportDtos = detailReportDtos
    // if (compName === 'barChart' && dataOptionList[1].list.length === 2) {
    //   const obj = dataOptionList[0].list[0].level === '2' ? { dimensionName: dataOptionList[0].list[0].pId, levelName: dataOptionList[0].list[0].value }
    //     : { dimensionName: dataOptionList[0].list[0].value, levelName: dataOptionList[0].list[0].value }
    //   reportConfig.subtotalList.push(obj)
    // }
    // 针对于表格，维度进行小计和合计的转化, 先处理行维
    if (compName === 'mdxTable' && dataOptionList[0].list.length > 0) {
      // 如果有一个合计
      const findTotalIndex = dataOptionList[0].list.findIndex(item => item.totalValue.indexOf('hj') > -1)
      if (findTotalIndex > -1) {
        reportConfig.isTotal = '1'
      }
      // 最后一个行维无法进行小计，要剔除
      for (let i = 0; i < dataOptionList[0].list.length - 1; i++) {
        const item = dataOptionList[0].list[i]
        if (item.totalValue.indexOf('xj') > -1) {
          const obj = item.level === '2' ? { dimensionName: item.value, levelName: item.value }
            : { dimensionName: item.value, levelName: item.value }
          reportConfig.subtotalList.push(obj)
        }
      }
    }
    // console.log('***********************reportConfig' + JSON.stringify(reportConfig))
    return reportConfig
  }
  return transDataToReportConfig
})

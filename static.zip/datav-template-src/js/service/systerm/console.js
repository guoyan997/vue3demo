function _console () {
  var args = (arguments.length === 1 ? [arguments[0]] : Array.apply(null, arguments))
  if (window.runDebugger === true) {
    console.log(args)
  }
}

window._console = _console

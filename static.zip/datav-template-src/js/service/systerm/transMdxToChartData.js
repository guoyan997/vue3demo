define([], function () {
  const transMdxToChartData = ({ resultList }, schema) => {
    const mdxList = resultList || []
    const dataList = []
    if (mdxList && mdxList.length > 0) {
      if (!schema.dataOptionList[2] || (schema.dataOptionList[2] && schema.dataOptionList[2].list.length === 0)) {
        // 说明没有系列
        const firstRow = []
        for (let first of mdxList[0]) {
          firstRow.push(first.value)
        }
        dataList.push(firstRow)
        for (let i = 1; i < mdxList.length; i++) {
          const row = []
          for (let d of mdxList[i]) {
            row.push(d.value)
          }
          dataList.push(row)
        }
      } else {
        // 如果是含有系列值，先找出所有的该系列的值
        let seriesName = []
        for (let i = 1; i < mdxList.length; i++) {
          seriesName.push(mdxList[i][1].value)
        }
        seriesName = Array.from(new Set(seriesName))
        const seriesLength = seriesName.length
        const firstRow = [''].concat(seriesName)
        dataList.push(firstRow)
        for (let i = 1; i < mdxList.length; i += seriesLength) {
          const endLength = (i + seriesLength) <= mdxList.length ? (i + seriesLength) : mdxList.length
          const tempList = mdxList.slice(i, endLength)
          const row = []
          row.push(tempList[0][0].value)
          for (let j = 0; j < seriesLength; j++) {
            if (j < tempList.length) {
              row.push(tempList[j].length >= 3 ? tempList[j][2].value : 0)
            }
          }
          dataList.push(row)
        }
      }
    }
    return dataList
  }
  return transMdxToChartData
})

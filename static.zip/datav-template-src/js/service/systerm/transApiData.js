/** respArr 是接口返回的数据，为数组类型
 * compKeys 是接口字段和数组字段的关系数组
 */
define(['js/service/systerm/weapon.js'], function (weapon) {
  const transApiData = (respArr, compKeys) => {
    let dataList = []
    for (let resp of respArr) {
      const obj = {}
      for (let key of compKeys) {
        let data = ''
        // 如果结果数组对象中没有指定的属性名, 或者返回的值是空
        if (!resp.hasOwnProperty(key.apiProp) || resp[key.apiProp] === '') {
          data = key.dealNull
        } else {
          data = resp[key.apiProp]
        }
        // 数字精度，小数点位数
        const decimal = key.decimal
        // 是否要转化百分比
        if (key.bfb && weapon.isNumber(data)) {
          data = (parseFloat(data) * 100).toFixed(decimal)
        }
        // 是否要进行千分位格式化
        if (key.qfw && weapon.isNumber(data)) {
          data = weapon.formatNumber(data, decimal)
        } else if (!key.qfw && weapon.isNumber(data)) {
          data = parseFloat(data).toFixed(decimal)
        }
        obj[key.comProp] = data
      }
      dataList.push(obj)
    }
    return dataList
  }
  return transApiData
})

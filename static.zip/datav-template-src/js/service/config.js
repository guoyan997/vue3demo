/**
 * @description 配置默认的资源路径
 */
define([], function () {
  window.runDebugger && console.log('config.js window.location.href=', window.location.href)
  let resourceHost = '/dataV/'
  // Local Dev
  if (window.location.href.indexOf('http://localhost') > -1 ||
    window.location.href.indexOf('http://0.0.0.0') > -1) {
    resourceHost = 'http://localhost:8080/dataV/'
  }
  return {
    resourceServerHost: resourceHost
  }
})

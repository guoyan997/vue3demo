/**
 * @description 系统模型
 * @author chenqy9
 */
// 注意：这里的路径是相对于main.js
define([
  // 'lib/vue.js',
  // 'lib/vue-router.js',
  'echarts',
  'lib/china.js',
  'lib/lodash.min.js',
  // 'lib/axios.min.js',
  'js/service/config',
  'js/constant/index.js',
  'js/mixins/index.js',
  'js/service/systerm/index.js'
], function (
  // Vue,
  // VueRouter,
  echarts,
  chinaMap,
  _,
  // axios,
  serviceConfig,
  constant,
  mixins,
  serviceSysterm
) {
  'use strict'
  window.isEditing = false // iframe处于非编辑模式
  // 用在renderWork中
  // Vue.config.productionTip = false
  // Vue.prototype.$eventHub = new Vue({}) // Vue事件总线
  // Vue.prototype.$http = axios

  const System = {}

  /**
   * 作品状态变量
   */
  System.State = {
    work: {},
    page: {}
  }

  const publicService = {}
  const global = {
    state: {
      work: {},
      page: {}
    },
    onlineConfig: {
      apiHost: '', // 接口域名
      sourceHost: '', // 资源域名
      defaultSourceHost: serviceConfig.resourceServerHost, // 默认的资源域名
      defaultHost: window.localStorage.getItem('hostUrl')
    },
    PageEvent: constant.PAGE_EVENT,
    WorkEvent: constant.WORK_EVENT,
    style: {
      // '#id1 .odometer-digit': {
      //   backgroundColor: '#F00',
      //   backgroundImage: 'ulr(http://10.73.14.103:8080/dataV/img/resource/demo1-bg1.jpg)',
      //   backgroundSize: '100% 100%'
      // },
    },
    // 这个对象用于记录被联动的组件列表和开启下钻的组件列表，用于判断是否显示还原、上一层等操作按钮
    actionRelation: {
      relationTargetList: [],
      selfDetailList: []
    }
  }

  /**
   * @description 格式化数据
   */
  publicService.formatNumber = global.formatNumber = serviceSysterm.formatNumber
  global.transApiData = serviceSysterm.transApiData
  global.transDataToReportConfig = serviceSysterm.transDataToReportConfig
  global.transMdxToChartData = serviceSysterm.transMdxToChartData
  global.compareSort = serviceSysterm.weapon.compareSort
  global.formatValue = serviceSysterm.formatValue
  global.exportFile = serviceSysterm.exportFile
  //  serviceSysterm.formatValue
  window.$publicService = publicService
  window.$global = global

  System.BasicCommonOption = constant.BasicCommonOption

  /**
   * 通用坐标轴配置
   */
  System.BasicCommonAxisOption = constant.BasicCommonAxisOption

  /**
   * 通用系列配置
   */
  System.CommonSeriesOption = constant.CommonSeriesOption

  /**
   * 通用柱状图系列配置
   */
  System.CommonBarSeriesOption = constant.CommonBarSeriesOption

  /**
   * 通用线图系列配置
   */
  System.CommonLineSeriesOption = constant.CommonLineSeriesOption

  /**
   * @description 可视化平台编辑系统事件
   */
  System.SYS_EVENT = constant.SYS_EVENT

  /**
   * @description 系统页面事件
   */
  System.PAGE_EVENT = constant.PAGE_EVENT

  /**
   * @description 组件类型
   */
  System.COMPONENT_TYPE = {
    'ECHART': 'ECHART',
    'PAGE': 'PAGE'
  }

  System.parse = serviceSysterm.parse

  /**
 * @description 请求数据
 * @param {String} url 接口地址
 * @param {String} method 请求方法
 * @param {[Object]} params 请求参数
 */
  System.request = serviceSysterm.request
  window.request = serviceSysterm.request

  /**
   * @description 组件mixins
   */
  System.COMPONENT_MIXIN = {
    'WORK': {
    },
    'PAGE': mixins.page,
    'ECHART': mixins.echart
  }

  System.vueComponentCreator = serviceSysterm.vueComponentCreator

  /**
   * @description 渲染作品
   */
  System.renderWork = serviceSysterm.renderWork

  window.echarts = echarts
  window._ = _
  // window.Vue = Vue // 在renderWork中执行

  return System
})

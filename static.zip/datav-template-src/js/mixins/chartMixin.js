/**
 * @description 图表混合
 */
// chartMixin，global要在chartMixin执行前挂载
// 注意这里的路径是相对于main.js
define([
  'lib/lodash.min.js',
  'js/constant/index.js',
  'js/service/systerm/request.js'
], function (
  _,
  constant,
  request
) {
  const chartMixin = {
    watch: {
      /**
       * @description 数据集变化时需要重新渲染
       */
      dataset: {
        handler: function () {
          this.getOption(this.dataset)
        },
        deep: true
      },
      reRender () {
        this.render()
      },
      seriesOptionList: {
        handler: function () {
          this.getOption()
        },
        deep: true
      },
      /**
       * @description 通用option配置变化时需要重新渲染
       */
      commonSeriesOption: {
        handler: function () {
          this.render()
        },
        deep: true
      },
      seriesOption: {
        handler: function () {
          this.render()
        },
        deep: true
      },
      commonBarSeriesOption: {
        handler: function () {
          this.render()
        },
        deep: true
      },
      commonLineSeriesOption: {
        handler: function () {
          this.render()
        },
        deep: true
      },
      // 通用标签格式化
      commonLabelFormatter: {
        handler: function () {
          this.render()
        },
        deep: true
      },
      commonTooltipFormatter: {
        handler: function () {
          this.render()
        },
        deep: true
      },
      /**
       * @description option变化时需要重新渲染
       */
      option: {
        handler: function () {
          this.render()
        },
        deep: true
      },
      seriesKeys: {
        handler: function () {
          this.getOption()
        },
        deep: true
      },
      indicatorKeys: {
        handler: function () {
          this.getOption()
        },
        deep: true
      },
      dimensionKeys: {
        handler: function () {
          this.getOption()
        },
        deep: true
      },
      stackKeys: {
        handler: function () {
          this.getOption()
        },
        deep: true
      },
      isReloadApiData () {
        this.getData()
      },
      events: {
        handler: function () {
          this.bindChartEvents()
        }
      },
      /**
       * @description 如果接口Url不存在，用静态数据渲染数据
       */
      '_api_.url': {
        handler: function (url) {
          if (!url && this.getOption) {
            this.getOption(this.dataset)
          }
        }
      },
      /**
       * @description 接口API参数变化时，需要重新监听状态
       */
      '_api_.params': {
        handler: function (val) {
          // 将旧的params上事件全部取消，重新绑定的事件
          if (this.self.lastParams && this.self.lastParams.length > 0) {
            for (let param of this.self.lastParams) {
              if (param.type === 'page' && param.stateName) {
                this.$eventHub.$off(constant.PAGE_EVENT.CHANGE_PAGE_STATE + '_' + param.stateName, this.getData)
              } else if (param.type === 'work' && param.stateName) {
                this.$eventHub.$off(constant.PAGE_EVENT.CHANGE_WORK_STATE + '_' + param.stateName, this.getData)
              }
            }
          }

          for (let param of this._api_.params) {
            if (param.type === 'page' && param.stateName) {
              this.$eventHub.$on(constant.PAGE_EVENT.CHANGE_PAGE_STATE + '_' + param.stateName, this.getData)
            } else if (param.type === 'work' && param.stateName) {
              this.$eventHub.$on(constant.PAGE_EVENT.CHANGE_WORK_STATE + '_' + param.stateName, this.getData)
            }
          }
        },
        deep: true
      }
    },
    methods: {
      /**
       * @description window resize时echarts需要重新渲染
       */
      resize () {
        if (this.echartsInstance) {
          console.log('mixin里的resize')
          this.echartsInstance.resize()
        }
      },
      /**
       * @description 请求API获取具体数据
       * @param {Boolean} 是否mounted的时候第一次次请求，如果是，接口请求异常时用静态数据渲染
       */
      getData (isMounted) {
        let paramsCopy = _.cloneDeep(this._api_.params) // 拷贝
        for (let param of paramsCopy) {
          if (param.type === 'page') {
            param.value = $global.state.page[param.stateName]
          } else if (param.type === 'work') {
            param.value = $global.state.work[param.stateName]
          }
        }

        let url = this._api_.url
        let patt = /^(http)/ // 匹配字段以http开头
        if (!patt.test(url)) {
          // 将host和接口api地址合并处理
          if ($global.onlineConfig && $global.onlineConfig.apiHost) {
            url = $global.onlineConfig.apiHost + url
          }
        }

        request(url, this._api_.method, paramsCopy).then(response => {
          // 数据结果集
          let result = {}
          // 返回的是字符串，要尝试将字符串转换成对象
          if (typeof response.data === 'string') {
            response.data = eval('(' + response.data + ')')
          }
          // 如果是接口平台类型，选取data字段，并且做字符串转json处理
          if (this._api_.type === 'cas') {
            result = typeof response.data.data === 'string' ? JSON.parse(response.data.data) : response.data.data
          } else {
            result = response.data
          }
          this.self.apiData = result[this.apiDataKey] || []
          this.$nextTick(() => {
            this.getOption(this.apiData, 'api')
          })
        }).catch(error => {
          console.error(`获取图表数据失败：${error}`)
          if (isMounted) {
            this.$nextTick(() => {
              this.getOption(this.dataset)
            })
          }
        })
      },
      /**
       * @description 构造option
       */
      getOption (dataset, dataType) {
        if (!dataset) {
          if (this.apiData && this.apiData.length > 0) {
            dataset = this.apiData
            dataType = 'api'
          } else {
            dataset = this.dataset
          }
        }
        if (this.dataProcessor) {
          this.dataProcessor(dataset, dataType)
        }
      },
      /**
       * @description 渲染图表
       */
      render () {
        try {
          this.echartsInstance = this.echartsInstance ||
            window.echarts.init(document.getElementById(this.id), this.theme)

          // 克隆配置，避免直接修改对象
          const optionCopy = _.cloneDeep(this.option)

          // 如果组件存在配置处理函数，则调用处理函数
          if (_.isFunction(this.processOption)) {
            this.processOption(optionCopy)
          }

          // 清除数据
          this.echartsInstance.clear()
          this.echartsInstance.setOption(optionCopy)

          // 绑定事件
          this.bindChartEvents()
          // 绑定该组件配置的所有动作
          this.bindEchartInstanceAction()
        } catch (error) {
          console.error(`渲染图表失败：${error}`)
        }
      },
      /**
       * @description 绑定图表事件
       */
      bindChartEvents () {
        try {
          // echarts组件
          const vm = this
          if (this.echartsInstance && this.events) {
            for (let event of this.events) {
              this.echartsInstance.off(event.eventType)
            }
            for (let event of this.events) {
              // 先取消事件绑定，防止重复绑定
              // this.echartsInstance.off(event.eventType) // 若有相同的时间类型时，前一个事件会被解绑掉
              // 重新绑定事件
              this.echartsInstance.on(event.eventType, function (params) {
                // event中的字段为：
                // {
                //   eventName: 'CHANGE_PAGE_STATE',
                //   eventType: 'click',
                //   param: 'name',
                //   stateName: 'page1test',
                //   stateType: 'PAGE'
                // }

                // 修改页面状态变量
                if (event.eventName === 'CHANGE_PAGE_STATE') {
                  $global.state.page[event.stateName] = params[event.param]
                } else if (event.eventName === constant.PAGE_EVENT.CHANGE_WORK_STATE) {
                  $global.state.work[event.stateName] = params[event.param]
                }

                // 触发事件（通知状态变量更新了）
                vm.$eventHub.$emit(event.eventName + '_' + event.stateName)
              })
            }

            // worktemplate上做一个全局的对象globalState来放state
          }
          // 监听修改状态变量
          for (let param of this._api_.params) {
            if (param.type === 'page' && param.stateName) {
              // param.stateName 为状态变量名称
              // 先取消事件绑定，防止重复绑定。（多个参数绑定同一个事件）
              this.$eventHub.$off(constant.PAGE_EVENT.CHANGE_PAGE_STATE + '_' + param.stateName, this.getData)
              // 请求数据，请求数据时会把最新的状态赋值给请求参数
              this.$eventHub.$on(constant.PAGE_EVENT.CHANGE_PAGE_STATE + '_' + param.stateName, this.getData)
            } else if (param.type === 'work' && param.stateName) {
              this.$eventHub.$off(constant.PAGE_EVENT.CHANGE_WORK_STATE + '_' + param.stateName, this.getData)
              this.$eventHub.$on(constant.PAGE_EVENT.CHANGE_WORK_STATE + '_' + param.stateName, this.getData)
            }
          }
        } catch (error) {
          console.error(`绑定图表事件失败：${error.message}`)
        }
      },
      /**
      * 接收联动信号
      * from 是来至于哪个组件发出的信号
      * to 是信号要发送给哪个组件,是个组件列表
      * outParams 是信号携带的外部参数数据
      */
      receiveRelationAction (relationShip) {
        const { to, outParams } = relationShip
        const find = to.findIndex(item => item === this.blockId)
        if (find > -1) {
          // 说明这个信号是命令这个组件的
          const fiters = outParams[0].filters
          const params = fiters.filter(item => item.targetId === this.blockId)
          const relationFilter = [{ andOr: 'and', filters: params }]
          if (this.schema.filter.relationFilter[0]) { // 有重复的filter要去掉
            let oldFilters = this.schema.filter.relationFilter[0].filters
            let differenceArr = window._.differenceBy(oldFilters, params, 'fromId')
            let allFilters = [...differenceArr, ...params]
            this.schema.filter.relationFilter = [{ andOr: 'and', filters: allFilters }]// schema变化，则引起重新查数据
          } else {
            // console.log('没旧的filters')
            this.schema.filter.relationFilter = relationFilter // schema变化，则引起重新查数据
          }
        }
      },
      // 当组件的动作有改变（如 修改动作，添加动作等），要接收到动作的通知
      receiveChangeAction ({ componentId, action }) {
        // 获取最新的动作配置,然后再重新绑定事件，配置参数
        if (componentId !== this.blockId) {
          return
        }
        this.self.action = action
        this.bindEchartInstanceAction()
      },
      // 重新绑定动作到echart实例上
      bindEchartInstanceAction () {
        for (let eventType of this.action.triggerTypeList) {
          this.echartsInstance.off(eventType.value)
        }
        let eventTypeList = []
        if (this.action.selfDetail) {
          eventTypeList = [this.action.detail.triggerTypeValue]
          // 然后重新绑定事件
          for (let event of eventTypeList) {
            const self = this
            this.echartsInstance.on(event, function (params) {
              self.selfDetailShip(params, event)
            })
          }
        } else {
          for (let item of this.action.itemList) {
            eventTypeList.push(item.triggerTypeValue)
          }
          eventTypeList = Array.from(new Set(eventTypeList))
          // 然后重新绑定事件
          for (let event of eventTypeList) {
            const self = this
            this.echartsInstance.on(event, function (params) {
              self.sendRelationShip(params, event)
            })
          }
        }
      },
      clearLinkActionParam ({ to }) {
        const find = to.findIndex(item => item === this.blockId)
        if (find > -1) {
          // 说明这个信号是命令这个组件的
          this.schema.filter.linkFilter = [] // schema变化，则引起重新查数据
        }
      },
      // 联动数据清除
      actionRecover ({ to }) {
        if (to === this.blockId) {
          // 通知该组件上钻
          this.schema.filter.relationFilter = []
        }
      },
      // 返回上一层
      changeSelfLevelToUp ({ to, top }) {
        debugger
        if (this.action.selfDetail && to === this.blockId) {
          // 通知该组件上钻
          this.changeLevelToUp(top)
        }
      },
      /**
       * @description 绑定事件
       */
      bindEvents () {
        window.addEventListener('resize', this.resize)
        this.$eventHub.$on(constant.SYS_EVENT.RESIZE_WINDOW, this.resize)
        this.$eventHub.$on(constant.SYS_EVENT.RESIZE_CHART, this.resize)
        this.$eventHub.$on(constant.SYS_EVENT.RERENDER_CHART, this.render)
        this.$eventHub.$on(constant.SYS_EVENT.BIND_CHART_EVENT, this.bindChartEvents)
      },
      /**
       * @description 解绑事件
       */
      unbindEvents () {
        window.removeEventListener('resize', this.resize)
        this.$eventHub.$off(constant.SYS_EVENT.RESIZE_WINDOW, this.resize)
        this.$eventHub.$off(constant.SYS_EVENT.RESIZE_CHART, this.resize)
        this.$eventHub.$off(constant.SYS_EVENT.RERENDER_CHART, this.render)
        this.$eventHub.$off(constant.PAGE_EVENT.CHANGE_PAGE_STATE, this.getData)
        this.$eventHub.$off(constant.SYS_EVENT.BIND_CHART_EVENT, this.bindChartEvents)
        this.$eventHub.$off('receiveRelationAction')
        this.$eventHub.$off('receiveChangeAction')
        this.$eventHub.$off('clearLinkActionParam')
        this.$eventHub.$off('actionRecover')
        this.$eventHub.$off('changeSelfLevelToUp')
        this.unbindStateEvents()
      },
      /**
       * @description 解绑状态变量事件
       */
      unbindStateEvents () {
        for (let param of this._api_.params) {
          if (param.type === 'page' && param.stateName) {
            this.$eventHub.$off(constant.PAGE_EVENT.CHANGE_PAGE_STATE + '_' + param.stateName, this.getData)
          } else if (param.type === 'work' && param.stateName) {
            this.$eventHub.$off(constant.PAGE_EVENT.CHANGE_WORK_STATE + '_' + param.stateName, this.getData)
          }
        }
      }
    },
    created () {
      try {
        // 解除事件并重新监听，避免重复绑定
        this.unbindEvents()
        this.bindEvents()
        // 请求数据
        if (this._api_ && this._api_.url && this._api_.method) {
          this.getData()
        } else {
          this.getOption(this.dataset)
        }
      } catch (error) {
        console.error(`创建图表时失败：${error}`)
      }
      // 这里要获取跳转过来传递的参数
      const linkAction = JSON.parse(localStorage.getItem('outParams'))
      if (linkAction) {
        const findx = linkAction.to.findIndex(item => item === this.blockId)
        if (findx > -1 && this.runMode !== 'dev') {
          const outParams = linkAction.outParams.map(param => {
            param.filters = param.filters.filter(f => f.targetId === this.blockId)
            return param
          })
          this.schema.filter.linkFilter = outParams // 这里直接会触发watch查询
        } else {
          this.changeSchema(this.schema)
        }
      } else {
        this.changeSchema(this.schema)
      }
    },
    mounted () {
      // 绑定联动监听事件
      this.$eventHub.$on('receiveRelationAction', this.receiveRelationAction)
      this.$eventHub.$on('receiveChangeAction', this.receiveChangeAction)
      this.$eventHub.$on('clearLinkActionParam', this.clearLinkActionParam)
      this.$eventHub.$on('actionRecover', this.actionRecover)
      this.$eventHub.$on('changeSelfLevelToUp', this.changeSelfLevelToUp)
    },
    beforeDestroy () {
      // 解绑事件
      this.unbindEvents()
      if (this.echartsInstance) {
        this.echartsInstance.clear()
        this.echartsInstance.dispose()
        this.echartsInstance = null
      }
    }
  }
  return chartMixin
})

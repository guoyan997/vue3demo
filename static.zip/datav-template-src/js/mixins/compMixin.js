/**
 * 普通组件，添加相关公共方法
 */

define([], function () {
  const compMixin = {
    methods: {
      /**
       * 接收联动信号
       * from 是来至于哪个组件发出的信号
       * to 是信号要发送给哪个组件,是个组件列表
       * outParams 是信号携带的外部参数数据
       */
      receiveRelationAction (relationShip) {
        const { to, outParams } = relationShip
        const find = to.findIndex(item => item === this.blockId)
        if (find > -1) {
          // 说明这个信号是命令这个组件的
          const fiters = outParams[0].filters
          const params = fiters.filter(item => item.targetId === this.blockId)
          const relationFilter = [{ andOr: 'and', filters: params }]
          if (this.schema.filter.relationFilter[0]) { // 有重复的filter要去掉
            let oldFilters = this.schema.filter.relationFilter[0].filters
            let differenceArr = window._.differenceBy(oldFilters, params, 'fromId')
            let allFilters = [...differenceArr, ...params]
            this.schema.filter.relationFilter = [{ andOr: 'and', filters: allFilters }]// schema变化，则引起重新查数据
          } else {
            // console.log('没旧的filters')
            this.schema.filter.relationFilter = relationFilter // schema变化，则引起重新查数据
          }
        }
      },
      // 当组件的动作有改变（如 修改动作，添加动作等），要接收到动作的通知
      receiveChangeAction ({ componentId, action }) {
        // 获取最新的动作配置,然后再重新绑定事件，配置参数
        if (componentId !== this.blockId) {
          return
        }
        this.self.action = action
      },
      // 联动数据清除
      actionRecover ({ to }) {
        if (to === this.blockId) {
          // 通知该组件上钻
          this.schema.filter.relationFilter = []
        }
      },
      // 清除跳转数据
      clearLinkActionParam ({ to }) {
        const find = to.findIndex(item => item === this.blockId)
        if (find > -1) {
          // 说明这个信号是命令这个组件的
          this.schema.filter.linkFilter = [] // schema变化，则引起重新查数据
        }
      },
      // 绑定事件, 用于接收联动消息
      bindEvent () {
        this.$eventHub.$on('receiveRelationAction', this.receiveRelationAction)
        this.$eventHub.$on('receiveChangeAction', this.receiveChangeAction)
        this.$eventHub.$on('clearLinkActionParam', this.clearLinkActionParam)
        this.$eventHub.$on('actionRecover', this.actionRecover)
      },
      unBindEvent () {
        this.$eventHub.$off('receiveRelationAction')
        this.$eventHub.$off('clearLinkActionParam')
        this.$eventHub.$off('actionRecover')
      }
    },
    created () {
      // 这里要获取跳转过来传递的参数
      const linkAction = JSON.parse(localStorage.getItem('outParams'))
      if (linkAction) {
        const findx = linkAction.to.findIndex(item => item === this.blockId)
        if (findx > -1 && this.runMode !== 'dev') {
          const outParams = linkAction.outParams.map(param => {
            param.filters = param.filters.filter(f => f.targetId === this.blockId)
            return param
          })
          this.schema.filter.linkFilter = outParams // 这里直接会触发watch查询
        } else {
          this.changeSchema(this.schema)
        }
      } else {
        this.changeSchema(this.schema)
      }
    },
    mounted () {
      this.bindEvent()
    },
    beforeDestroy () {
      this.unBindEvent()
    }
  }
  return compMixin
})

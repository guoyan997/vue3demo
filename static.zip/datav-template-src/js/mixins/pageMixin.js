/**
 * @description 页面混合
 */
// pageMixin，global要在pageMixin执行前挂载

// 注意这里的路径是相对于main.js
define([
  'js/constant/index.js'
  // 'js/service/config.js'
], function (
  constant
  // serviceConfig
) {
  return {
    methods: {
      /**
       * @description 初始化页面状态
       */
      initPageState () {
        this.inlineStyle.fontFamily = $global.fontFamily
        let patt = /^(http|\/\/)/ // 匹配字段以http开头或以//开头
        if (this.backgroundImage && !patt.test(this.backgroundImage)) {
          if ($global && $global.onlineConfig && $global.onlineConfig.sourceHost) {
            // 拼接host和图片路径
            this.inlineStyle.backgroundImage = 'url(' + $global.onlineConfig.sourceHost + this.backgroundImage + ')'
          } else {
            this.inlineStyle.backgroundImage = 'url(' + $global.onlineConfig.defaultSourceHost + this.backgroundImage + ')'
          }
        } else {
          this.inlineStyle.backgroundImage = 'url(' + this.backgroundImage + ')'
        }
        if ($global.routerSet.routerTipImg && !patt.test($global.routerSet.routerTipImg)) {
          if ($global && $global.onlineConfig && $global.onlineConfig.sourceHost) {
            // 拼接host和图片路径
            $global.routerSet.routerTipImgUrl = 'url(' + $global.onlineConfig.sourceHost + $global.routerSet.routerTipImg + ')'
          } else {
            $global.routerSet.routerTipImgUrl = 'url(' + $global.onlineConfig.defaultSourceHost + $global.routerSet.routerTipImg + ')'
          }
        } else {
          $global.routerSet.routerTipImgUrl = 'url(' + $global.routerSet.routerTipImg + ')'
        }

        if (this.initFullScreenImg) {
          this.initFullScreenImg() // 设置全屏按钮图片
        }

        if (this.initPlaySetImg) {
          this.initPlaySetImg() // 设置播放暂停按钮图片
        }

        // 若添加了状态变量，但是未取名、赋值呢？被undefined名覆盖
        if (this.states && this.states.length > 0) {
          for (let state of this.states) {
            $global.state.page[state.name] = state.initValue
          }
        }
        window.runDebugger && console.log('after $global.state=', $global.state)

        if (this.stateTimer) {
          for (let x in this.stateTimer) {
            clearInterval(this.stateTimer[x])
          }
        }
        this.stateTimer = {}
        if (this.states && this.states.length > 0) {
          for (let state of this.states) {
            if (state.changeType === 'timer') {
              const valueList = state.values.split(',')
              window.runDebugger && console.log('valueList=', valueList)
              this[`page_state_${state.name}`] = valueList[0] // 每个定时页面状态变量 存值 （状态变量不能重名）

              if (valueList.length > 1) {
                this.stateTimer[`page_state_${state.name}`] = setInterval(() => {
                  let currentIndex = valueList.indexOf(this[`page_state_${state.name}`]) // 记住切换到哪个索引了
                  const index = (++currentIndex) % valueList.length
                  this[`page_state_${state.name}`] = valueList[index]

                  $global.state.page[state.name] = this[`page_state_${state.name}`]
                  this.$eventHub.$emit(constant.PAGE_EVENT.CHANGE_PAGE_STATE + '_' + state.name)
                }, state.changeInterval)
              }
            }
          }
        }
      }
    },
    created () {
      try {
        window.runDebugger && console.log('=== 页面created ===') // 执行pageviewer的renderpage后，这里的created就会执行
        this.initPageState()
      } catch (error) {
        window.runDebugger && console.log(`页面创建时发生错误：${error}`)
      }
    },
    mounted () {
      if ($global.workStyle.backgroundImage || $global.workStyle.backgroundColor) {
        // do nothing
      } else {
        let that = this
        this.$nextTick(function () {
          window.runDebugger && console.log('pageMixn $nextTick')
          setTimeout(function () {
            let workEle = document.getElementById('app')
            workEle.style.backgroundImage = that.inlineStyle.backgroundImage
            workEle.style.backgroundSize = '100% 100%'
          }, 1000)
        })
      }
    },
    beforeDestroy () {
      try {
        window.runDebugger && console.log('=== 销毁页面 ===')
        if (this.stateTimer) {
          for (let x in this.stateTimer) {
            clearInterval(this.stateTimer[x])
          }
        }
      } catch (error) {
        window.runDebugger && console.log(`页面销毁时发生错误：${error}`)
      }
    }
  }
})

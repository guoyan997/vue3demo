define([
  'js/mixins/chartMixin.js',
  'js/mixins/pageMixin.js',
  'js/mixins/compMixin.js'
], function (
  chartMixin,
  pageMixin,
  compMixin
) {
  return {
    echart: chartMixin,
    page: pageMixin,
    comp: compMixin
  }
})


// ======== 水星大屏测试接口 ======== //

/**
 * @description sxjf/yyzl_1 运营总览-业绩达成 左上
 */
window.Mock.mock(/(sxjf\/yyzl_1)$/, options => {
  return {
    res: {
      achieveAmt: 189935136.17980000,
      achieveGapToLy: -2963210413.48030000,
      achieveGapToTarget: 2953854863.81820000,
      achieveLyAmt: 3153145549.66010000,
      achievePerc: 0.060415974407,
      achieveTarget: 3143789999.9980,
      achieveYoy: -0.9243
    }
  }
})

/**
 * @description sxjf/yyzl_1a 运营总览-业绩达成 左上 不含税金额
 */
window.Mock.mock(/(sxjf\/yyzl_1a)$/, options => {
  return {
    res: {
      amt: 163737186.36189655
    }
  }
})

/**
 * @description sxjf/yyzl_2 运营总览-库存达成 右上
 */
window.Mock.mock(/(sxjf\/yyzl_2)$/, options => {
  return {
    res: [{
      dcRate: '0.0253',
      gapToLt: '369819386.3170',
      gapToTarget: '27109206.8829',
      ingrAmt: '133730534.18581381',
      invAmt: '777199669.8617',
      ltAmt: '674991406.8000',
      prodAmt: '643469135.67589230',
      qtq: '0.5479',
      targetAmt: '1071920000.0000'
    }]
  }
})

/**
 * @description sxjf/yyzl_3a 运营总览-销售出库 订货完成率
 */
window.Mock.mock(/(sxjf\/yyzl_3a)$/, options => {
  return {
    res: {
      rate: 0.32150224
    }
  }
})

/**
 * @description sxjf/yyzl_3b 运营总览-销售出库 执行率
 */
window.Mock.mock(/(sxjf\/yyzl_3b)$/, options => {
  return {
    res: {
      mtdQtyRate: '0.847642893333',
      performRate: '0.445524970000'
    }
  }
})

/**
 * @description sxjf/yyzl_3 运营总览-销售出库 下1柱状图
 */
window.Mock.mock(/(sxjf\/yyzl_3)$/, options => {
  return {
    res: [
      {planQty: '2138085.00000000', examSub: '电子商务', actualQty: '322850.00000000', performRate: '0.116603490000'},
      {planQty: '516588.00000000', examSub: '水星', actualQty: '235127.00000000', performRate: '0.308345920000'}
    ]
  }
})

/**
 * @description sxjf/yyzl_4a 运营总览-计划入库 月满足率
 */
window.Mock.mock(/(sxjf\/yyzl_4a)$/, options => {
  return {
    res: {
      rate: '0.942467000000'
    }
  }
})

/**
 * @description sxjf/yyzl_4b 运营总览-计划入库 计划数据
 */
window.Mock.mock(/(sxjf\/yyzl_4b)$/, options => {
  return {
    res: {
      performQty: '519197.00000000',
      performRate: '0.206976198000',
      planQty: '1731115.00000000'
    }
  }
})

/**
 * @description sxjf/yyzl_4 运营总览-计划入库 下2柱状图
 */
window.Mock.mock(/(sxjf\/yyzl_4)$/, options => {
  return {
    res: [
      {performQty: '246782.00000000', invQty: '736869.00000000', examSub: '水星', performRate: '0.127337870000'},
      {performQty: '169233.00000000', invQty: '670023.00000000', examSub: '电子商务', performRate: '0.144902820000'},
      {performQty: '69119.00000000', invQty: '151174.00000000', examSub: '百丽丝', performRate: '0.190788100000'},
      {performQty: '43935.00000000', invQty: '148718.00000000', examSub: '大客户', performRate: '0.222942940000'},
      {performQty: '9984.00000000', invQty: '24531.00000000', examSub: '外贸', performRate: '0.373981850000'}
    ]
  }
})

/**
 * @description sxjf/yyzl_5a 运营总览-采购入库 月主料执行率
 */
window.Mock.mock(/(sxjf\/yyzl_5a)$/, options => {
  return {
    res: {
      execRate: '0.43894712'
    }
  }
})

/**
 * @description sxjf/yyzl_5b 运营总览-采购入库 执行率
 */
window.Mock.mock(/(sxjf\/yyzl_5b)$/, options => {
  return {
    res: {
      ontimeRate: '0.050740420037',
      performRate: '0.083993496440'
    }
  }
})

/**
 * @description sxjf/yyzl_5 运营总览-采购入库 下3柱状图
 */
window.Mock.mock(/(sxjf\/yyzl_5)$/, options => {
  return {
    res: [
      {performQty: '39460.0000', examSub: '电子商务', applyQty: '304290.0000', performRate: '0.0336'},
      {performQty: '29693.0000', examSub: '水星', applyQty: '207276.0000', performRate: '0.0289'},
      {performQty: '21693.0000', examSub: '百丽丝', applyQty: '39290.0000', performRate: '0.0000'},
      {performQty: '33786.5000', examSub: '外贸', applyQty: '35497.0000', performRate: '0.8180'},
      {performQty: '1635.0000', examSub: '大客户', applyQty: '11000.0000', performRate: '0.2044'}
    ]
  }
})

/**
 * @description sxjf/yyzl_6a 运营总览-生产入库 数据
 */
window.Mock.mock(/(sxjf\/yyzl_6a)$/, options => {
  return {
    res: {
      ontimeRate: '0.542084547821',
      performQty: '454383.00000000',
      performRate: '0.675206773490',
      planQty: '658976.00000000'
    }
  }
})

/**
 * @description sxjf/yyzl_6 运营总览-生产入库 下4柱状图
 */
window.Mock.mock(/(sxjf\/yyzl_6)$/, options => {
  return {
    res: [
      {planQty: '328971.00000000', examSub: '水星', warehouseNum: '234497.00000000', performRate: '0.638957152647'},
      {planQty: '228142.00000000', examSub: '电子商务', warehouseNum: '179457.00000000', performRate: '0.741449128085'},
      {planQty: '56444.00000000', examSub: '百丽丝', warehouseNum: '14349.00000000', performRate: '0.481096982639'},
      {planQty: '38416.00000000', examSub: '大客户', warehouseNum: '19106.00000000', performRate: '0.816601360000'},
      {planQty: '7003.00000000', examSub: '外贸', warehouseNum: '6974.00000000', performRate: '0.998964285000'}
    ]
  }
})

/**
 * @description sxjf/yjdc_1 业绩达成 左上柱状图
 */
window.Mock.mock(/(sxjf\/yjdc_1)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '主体') {
    return {
      res: [
        { targetAmt: 1584800000.00000000, rate: 0.994624179543, dim: '水星', yearAmt: 1576280399.74000000 }, { targetAmt: 1366140003.00000000, rate: 0.857907218028, dim: '电子商务', yearAmt: 1172021369.41000000 }, { targetAmt: 165200000.00000000, rate: 0.855167721005, dim: '百丽丝', yearAmt: 141273707.51000000 }, { targetAmt: 153634500.00000000, rate: 0.973671268237, dim: '直营', yearAmt: 149589498.46000000 }, { targetAmt: 70000000.00000000, rate: 0.725693301714, dim: '大客户', yearAmt: 50798531.12000000 }, { targetAmt: 20000000.00000000, rate: 0.542602087960, dim: '外贸', yearAmt: 10852041.75920000 }
      ]
    }
  } else {
    return {
      res: [
        { targetAmt: 1132100000.00000000, rate: 0.864624179543, dim: '水星', yearAmt: 121280399.74000000 }, { targetAmt: 1102140003.00000000, rate: 0.927907218028, dim: '电子商务', yearAmt: 932021369.41000000 }, { targetAmt: 125200000.00000000, rate: 0.805167721005, dim: '百丽丝', yearAmt: 111273707.51000000 }, { targetAmt: 123634500.00000000, rate: 0.923671268237, dim: '直营', yearAmt: 121589498.46000000 }, { targetAmt: 65000000.00000000, rate: 0.695693301714, dim: '大客户', yearAmt: 48798531.12000000 }, { targetAmt: 19000000.00000000, rate: 0.522602087960, dim: '外贸', yearAmt: 8852041.75920000 }
      ]
    }
  }
})

/**
 * @description sxjf/yjdc_2 业绩达成 右上
 */
window.Mock.mock(/(sxjf\/yjdc_2)$/, options => {
  return {
    res: [
      {yoy: '-0.68858333', examSub: '其他', rate: '0.7265', yearAmt: '3752013.68500000'},
      {yoy: '-0.84440000', examSub: '外贸', rate: '0.6321', yearAmt: '1712416.12780000'},
      {yoy: '-0.84480000', examSub: '大客户', rate: '0.5465', yearAmt: '8396167.09000000'},
      {yoy: '-0.93120000', examSub: '水星', rate: '0.8781', yearAmt: '109210421.75400000'},
      {yoy: '-0.92600000', examSub: '电子商务', rate: '0.7003', yearAmt: '87583283.50500000'},
      {yoy: '-0.95540000', examSub: '百丽丝', rate: '0.7321', yearAmt: '6440235.56000000'},
      {yoy: '-0.93410000', examSub: '直营', rate: '0.6865', yearAmt: '10026143.30000000'}
    ]
  }
})

/**
 * @description sxjf/yjdc_3 业绩达成 左下
 */
window.Mock.mock(/(sxjf\/yjdc_3)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '主体') {
    return {
      res: [
        { rate: '0.988779208008', yearMon: '201801', dim: '水星' }, { rate: '0.897049092550', yearMon: '201801', dim: '电子商务' }, { rate: '1.070268102041', yearMon: '201801', dim: '百丽丝' }, { rate: '0.982177749286', yearMon: '201801', dim: '直营' }, { rate: '1.722084321667', yearMon: '201801', dim: '大客户' }, { rate: '1.377862610200', yearMon: '201801', dim: '外贸' }, { rate: '0.561208934053', yearMon: '201802', dim: '水星' }, { rate: '0.826659235991', yearMon: '201802', dim: '电子商务' }, { rate: '0.421072577528', yearMon: '201802', dim: '百丽丝' }, { rate: '0.985002070185', yearMon: '201802', dim: '直营' }, { rate: '2.214996000000', yearMon: '201802', dim: '大客户' }, { rate: '0.016680203200', yearMon: '201802', dim: '外贸' }, { rate: '1.121833492744', yearMon: '201803', dim: '水星' }, { rate: '0.848052881768', yearMon: '201803', dim: '电子商务' }, { rate: '1.203162179130', yearMon: '201803', dim: '百丽丝' }, { rate: '0.813550982478', yearMon: '201803', dim: '直营' }, { rate: '0.440981178000', yearMon: '201803', dim: '大客户' }, { rate: '0.157389649850', yearMon: '201803', dim: '外贸' }, { rate: '1.087475570927', yearMon: '201804', dim: '水星' }, { rate: '0.721574271223', yearMon: '201804', dim: '电子商务' }, { rate: '0.607986389619', yearMon: '201804', dim: '百丽丝' }, { rate: '0.780967763062', yearMon: '201804', dim: '直营' }, { rate: '0.630622400000', yearMon: '201804', dim: '大客户' }, { rate: '0.654414243733', yearMon: '201804', dim: '外贸' }, { rate: '0.920702728486', yearMon: '201805', dim: '水星' }, { rate: '0.984476531285', yearMon: '201805', dim: '电子商务' }, { rate: '0.592927782278', yearMon: '201805', dim: '百丽丝' }, { rate: '1.060913299110', yearMon: '201805', dim: '直营' }, { rate: '1.022653170000', yearMon: '201805', dim: '大客户' }, { rate: '0.577036336733', yearMon: '201805', dim: '外贸' }, { rate: '0.960318701373', yearMon: '201806', dim: '水星' }, { rate: '0.455667924618', yearMon: '201806', dim: '电子商务' }, { rate: '0.752197109091', yearMon: '201806', dim: '百丽丝' }, { rate: '0.954352264358', yearMon: '201806', dim: '直营' }, { rate: '0.611399166667', yearMon: '201806', dim: '大客户' }, { rate: '0.250950004100', yearMon: '201806', dim: '外贸' }, { rate: '0.859059523547', yearMon: '201807', dim: '水星' }, { rate: '0.672125601636', yearMon: '201807', dim: '电子商务' }, { rate: '0.711616441880', yearMon: '201807', dim: '百丽丝' }, { rate: '0.714787343731', yearMon: '201807', dim: '直营' }, { rate: '0.382937600000', yearMon: '201807', dim: '大客户' }, { rate: '0.165824729450', yearMon: '201807', dim: '外贸' }, { rate: '1.041213998182', yearMon: '201808', dim: '水星' }, { rate: '0.645610900599', yearMon: '201808', dim: '电子商务' }, { rate: '0.786771583003', yearMon: '201808', dim: '百丽丝' }, { rate: '0.779066019825', yearMon: '201808', dim: '直营' }, { rate: '0.329631800000', yearMon: '201808', dim: '大客户' }, { rate: '0.885778127850', yearMon: '201808', dim: '外贸' }, { rate: '0.928068476835', yearMon: '201809', dim: '水星' }, { rate: '1.026555929423', yearMon: '201809', dim: '电子商务' }, { rate: '0.897000864103', yearMon: '201809', dim: '百丽丝' }, { rate: '0.899514552130', yearMon: '201809', dim: '直营' }, { rate: '0.627710500000', yearMon: '201809', dim: '大客户' }, { rate: '0.916002570600', yearMon: '201809', dim: '外贸' }, { rate: '0.927128012165', yearMon: '201810', dim: '水星' }, { rate: '0.901777128414', yearMon: '201810', dim: '电子商务' }, { rate: '0.684340715113', yearMon: '201810', dim: '百丽丝' }, { rate: '0.777968444456', yearMon: '201810', dim: '直营' }, { rate: '0.820545583333', yearMon: '201810', dim: '大客户' }, { rate: '0.898723854000', yearMon: '201810', dim: '外贸' }, { rate: '0.923330804561', yearMon: '201811', dim: '水星' }, { rate: '0.785006078081', yearMon: '201811', dim: '电子商务' }, { rate: '0.880751261250', yearMon: '201811', dim: '百丽丝' }, { rate: '0.825097936826', yearMon: '201811', dim: '直营' }, { rate: '0.710247428571', yearMon: '201811', dim: '大客户' }, { rate: '0.314004599400', yearMon: '201811', dim: '外贸' }, { rate: '0.914281914453', yearMon: '201812', dim: '水星' }, { rate: '0.825937818628', yearMon: '201812', dim: '电子商务' }, { rate: '0.782189501511', yearMon: '201812', dim: '百丽丝' }, { rate: '1.012212926357', yearMon: '201812', dim: '直营' }, { rate: '0.625619450000', yearMon: '201812', dim: '大客户' }, { rate: '0.433960130800', yearMon: '201812', dim: '外贸' }
      ]
    }
  } else {
    return {
      res: [
        { rate: '1.398779208008', yearMon: '201801', dim: '水星' }, { rate: '1.177049092550', yearMon: '201801', dim: '电子商务' }, { rate: '1.070268102041', yearMon: '201801', dim: '百丽丝' }, { rate: '0.982177749286', yearMon: '201801', dim: '直营' }, { rate: '1.722084321667', yearMon: '201801', dim: '大客户' }, { rate: '1.377862610200', yearMon: '201801', dim: '外贸' }, { rate: '0.561208934053', yearMon: '201802', dim: '水星' }, { rate: '0.826659235991', yearMon: '201802', dim: '电子商务' }, { rate: '0.421072577528', yearMon: '201802', dim: '百丽丝' }, { rate: '0.985002070185', yearMon: '201802', dim: '直营' }, { rate: '2.214996000000', yearMon: '201802', dim: '大客户' }, { rate: '0.016680203200', yearMon: '201802', dim: '外贸' }, { rate: '1.121833492744', yearMon: '201803', dim: '水星' }, { rate: '0.848052881768', yearMon: '201803', dim: '电子商务' }, { rate: '1.203162179130', yearMon: '201803', dim: '百丽丝' }, { rate: '0.813550982478', yearMon: '201803', dim: '直营' }, { rate: '0.440981178000', yearMon: '201803', dim: '大客户' }, { rate: '0.157389649850', yearMon: '201803', dim: '外贸' }, { rate: '1.087475570927', yearMon: '201804', dim: '水星' }, { rate: '0.721574271223', yearMon: '201804', dim: '电子商务' }, { rate: '0.607986389619', yearMon: '201804', dim: '百丽丝' }, { rate: '0.780967763062', yearMon: '201804', dim: '直营' }, { rate: '0.630622400000', yearMon: '201804', dim: '大客户' }, { rate: '0.654414243733', yearMon: '201804', dim: '外贸' }, { rate: '0.920702728486', yearMon: '201805', dim: '水星' }, { rate: '0.984476531285', yearMon: '201805', dim: '电子商务' }, { rate: '0.592927782278', yearMon: '201805', dim: '百丽丝' }, { rate: '1.060913299110', yearMon: '201805', dim: '直营' }, { rate: '1.022653170000', yearMon: '201805', dim: '大客户' }, { rate: '0.577036336733', yearMon: '201805', dim: '外贸' }, { rate: '0.960318701373', yearMon: '201806', dim: '水星' }, { rate: '0.455667924618', yearMon: '201806', dim: '电子商务' }, { rate: '0.752197109091', yearMon: '201806', dim: '百丽丝' }, { rate: '0.954352264358', yearMon: '201806', dim: '直营' }, { rate: '0.611399166667', yearMon: '201806', dim: '大客户' }, { rate: '0.250950004100', yearMon: '201806', dim: '外贸' }, { rate: '0.859059523547', yearMon: '201807', dim: '水星' }, { rate: '0.672125601636', yearMon: '201807', dim: '电子商务' }, { rate: '0.711616441880', yearMon: '201807', dim: '百丽丝' }, { rate: '0.714787343731', yearMon: '201807', dim: '直营' }, { rate: '0.382937600000', yearMon: '201807', dim: '大客户' }, { rate: '0.165824729450', yearMon: '201807', dim: '外贸' }, { rate: '1.041213998182', yearMon: '201808', dim: '水星' }, { rate: '0.645610900599', yearMon: '201808', dim: '电子商务' }, { rate: '0.786771583003', yearMon: '201808', dim: '百丽丝' }, { rate: '0.839066019825', yearMon: '201808', dim: '直营' }, { rate: '0.279631800000', yearMon: '201808', dim: '大客户' }, { rate: '0.965778127850', yearMon: '201808', dim: '外贸' }, { rate: '1.148068476835', yearMon: '201809', dim: '水星' }, { rate: '1.026555929423', yearMon: '201809', dim: '电子商务' }, { rate: '0.957000864103', yearMon: '201809', dim: '百丽丝' }, { rate: '1.159514552130', yearMon: '201809', dim: '直营' }, { rate: '0.537710500000', yearMon: '201809', dim: '大客户' }, { rate: '0.706002570600', yearMon: '201809', dim: '外贸' }, { rate: '0.867128012165', yearMon: '201810', dim: '水星' }, { rate: '0.771777128414', yearMon: '201810', dim: '电子商务' }, { rate: '0.804340715113', yearMon: '201810', dim: '百丽丝' }, { rate: '0.837968444456', yearMon: '201810', dim: '直营' }, { rate: '0.530545583333', yearMon: '201810', dim: '大客户' }, { rate: '0.748723854000', yearMon: '201810', dim: '外贸' }, { rate: '1.033330804561', yearMon: '201811', dim: '水星' }, { rate: '1.035006078081', yearMon: '201811', dim: '电子商务' }, { rate: '1.010751261250', yearMon: '201811', dim: '百丽丝' }, { rate: '1.025097936826', yearMon: '201811', dim: '直营' }, { rate: '0.840247428571', yearMon: '201811', dim: '大客户' }, { rate: '0.284004599400', yearMon: '201811', dim: '外贸' }, { rate: '0.734281914453', yearMon: '201812', dim: '水星' }, { rate: '1.095937818628', yearMon: '201812', dim: '电子商务' }, { rate: '0.902189501511', yearMon: '201812', dim: '百丽丝' }, { rate: '1.312212926357', yearMon: '201812', dim: '直营' }, { rate: '0.675619450000', yearMon: '201812', dim: '大客户' }, { rate: '0.673960130800', yearMon: '201812', dim: '外贸' }
      ]
    }
  }
})

/**
 * @description sxjf/yjdc_4 业绩达成 右下
 */
window.Mock.mock(/(sxjf\/yjdc_4)$/, options => {
  return {
    res: [
      {yoy: '-0.82370000', rate: '0.5345', channel: '其他', yearAmt: '3811233.68500000'},
      {yoy: '-0.84480000', rate: '0.4655', channel: '团购', yearAmt: '8396167.09000000'},
      {yoy: '-0.84440000', rate: '0.5125', channel: '外贸', yearAmt: '1712416.12780000'},
      {yoy: '-0.92600000', rate: '0.7003', channel: '电子商务', yearAmt: '87583283.50500000'},
      {yoy: '-0.94570000', rate: '0.6245', channel: '直属', yearAmt: '21692252.31000000'},
      {yoy: '-0.93410000', rate: '0.6865', channel: '直营', yearAmt: '10026143.30000000'},
      {yoy: '-0.92950000', rate: '0.7550', channel: '经销商', yearAmt: '93899155.00400000'}
    ]
  }
})

/**
 * @description sxjf/xlfx_1 销量分析 气泡地图数据
 */
window.Mock.mock(/(sxjf\/xlfx_1)$/, options => {
  return {
    res: [
      {yearAmt: '39957484.0760', prov: '上海'}, {yearAmt: '11937411.5800', prov: '云南省'}, {yearAmt: '1660294.9400', prov: '内蒙古自治区'}, {yearAmt: '6730917.0507', prov: '北京'}, {yearAmt: '580680.5800', prov: '吉林省'}, {yearAmt: '9564988.0640', prov: '四川省'}, {yearAmt: '1721182.1320', prov: '天津'}, {yearAmt: '109031.0300', prov: '宁夏回族自治区'}, {yearAmt: '15573758.3550', prov: '安徽省'}, {yearAmt: '8047548.7180', prov: '山东省'}, {yearAmt: '3471635.7240', prov: '山西省'}, {yearAmt: '8614884.6330', prov: '广东省'}, {yearAmt: '13518836.1200', prov: '广西壮族自治区'}, {yearAmt: '1719736.6600', prov: '新疆维吾尔自治区'}, {yearAmt: '9485063.5290', prov: '江苏省'}, {yearAmt: '10853326.5910', prov: '江西省'}, {yearAmt: '6153878.4820', prov: '河北省'}, {yearAmt: '8029001.8810', prov: '河南省'}, {yearAmt: '32673055.7130', prov: '浙江省'}, {yearAmt: '1405853.9570', prov: '海南省'}, {yearAmt: '7022952.4460', prov: '湖北省'}, {yearAmt: '14579219.6110', prov: '湖南省'}, {yearAmt: '4265995.7500', prov: '甘肃省'}, {yearAmt: '12243420.0790', prov: '福建省'}, {yearAmt: '31106.1100', prov: '西藏自治区'}, {yearAmt: '10495769.6700', prov: '贵州省'}, {yearAmt: '5890558.2580', prov: '辽宁省'}, {yearAmt: '9885218.2510', prov: '重庆'}, {yearAmt: '1455149.2800', prov: '陕西省'}, {yearAmt: '89144.1600', prov: '青海省'}, {yearAmt: '99.0000', prov: '香港特别行政区'}, {yearAmt: '3192958.9920', prov: '黑龙江省'}
    ]
  }
})

/**
 * @description sxjf/xlfx_1a 销量分析 全国销售数据
 */
window.Mock.mock(/(sxjf\/xlfx_1a)$/, options => {
  return {
    res: [
      {yearRate: '0.2598', yearAmt: '3042815062.8640'}
    ]
  }
})

/**
 * @description sxjf/xlfx_2 销量分析 6个模块
 */
window.Mock.mock(/(sxjf\/xlfx_2a)$/, options => {
  return {
    res: [
      {examSub: '水星', monRate: '0.7520', yearRate: '0.1598', yearAmt: '110965062.8640', yearTotalRate: '0.7520'}
    ]
  }
})
window.Mock.mock(/(sxjf\/xlfx_2b)$/, options => {
  return {
    res: [
      {examSub: '电子商务', monRate: '0.6797', yearRate: '0.0620', yearAmt: '85012157.215', yearTotalRate: '0.6797'}
    ]
  }
})
window.Mock.mock(/(sxjf\/xlfx_2c)$/, options => {
  return {
    res: [
      {examSub: '直营', monRate: '0.6571', yearRate: '0.0576', yearAmt: '9597668.92', yearTotalRate: '0.6571'}
    ]
  }
})
window.Mock.mock(/(sxjf\/xlfx_2d)$/, options => {
  return {
    res: [
      {examSub: '大客户', monRate: '0.2561', yearRate: '0.1571', yearAmt: '7824547.0900', yearTotalRate: '0.3521'}
    ]
  }
})
window.Mock.mock(/(sxjf\/xlfx_2e)$/, options => {
  return {
    res: [
      {examSub: '百丽丝', monRate: '0.2321', yearRate: '0.3162', yearAmt: '6411475.1200', yearTotalRate: '0.4171'}
    ]
  }
})
window.Mock.mock(/(sxjf\/xlfx_2f)$/, options => {
  return {
    res: [
      {examSub: '外贸', monRate: '0.6582', yearRate: '0.7652', yearAmt: '1712416.1278', yearTotalRate: '0.7852'}
    ]
  }
})

/**
 * @description sxjf/kckz_1 库存控制左上
 */
window.Mock.mock(/(sxjf\/kckz_1)$/, options => {
  return {
    res: [
      { examSub: '水星', targetAmt: '470000000.00000000', invAmt: '495299890.12627200' }, { examSub: '电子商务', targetAmt: '350000000.00000000', invAmt: '400442768.92612000' }, { examSub: '直营', targetAmt: '66597900.00000000', invAmt: '76270874.99340200' }, { examSub: '百丽丝', targetAmt: '60000000.00000000', invAmt: '62073894.79838200' }, { examSub: '大客户', targetAmt: '9000000.00000000', invAmt: '9752153.35161600' }, { examSub: '外贸', targetAmt: '500000.00000000', invAmt: '361397.33140100' }
    ]
  }
})

/**
 * @description sxjf/kckz_2 库存控制右上
 */
window.Mock.mock(/(sxjf\/kckz_2)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '水星') {
    return {
      res: [
        { diffRate: '-0.007350994461', turnRate: '103.98839483', yearMon: '201801' }, { diffRate: '0.019804021564', turnRate: '144.82383852', yearMon: '201802' }, { diffRate: '0.010015229307', turnRate: '121.99136422', yearMon: '201803' }, { diffRate: '-0.022072878996', turnRate: '113.52783249', yearMon: '201804' }, { diffRate: '0.031379863434', turnRate: '121.19264465', yearMon: '201805' }, { diffRate: '0.082705606467', turnRate: '124.41560805', yearMon: '201806' }, { diffRate: '-0.029435972692', turnRate: '136.88809414', yearMon: '201807' }, { diffRate: '-0.034470873222', turnRate: '144.95967175', yearMon: '201808' }, { diffRate: '0.053269428440', turnRate: '131.08131251', yearMon: '201809' }, { diffRate: '0.031465463205', turnRate: '122.39787522', yearMon: '201810' }, { diffRate: '0.011804059927', turnRate: '126.68816773', yearMon: '201811' }, { diffRate: '-0.092148596422', turnRate: '114.43528144', yearMon: '201812' }
      ]
    }
  } else if (body.name && body.name === '电子商务') {
    return {
      res: [
        { diffRate: '0.019804021564', turnRate: '144.82383852', yearMon: '201802' }, { diffRate: '0.010015229307', turnRate: '121.99136422', yearMon: '201803' }, { diffRate: '-0.022072878996', turnRate: '113.52783249', yearMon: '201804' }, { diffRate: '0.031379863434', turnRate: '121.19264465', yearMon: '201805' }, { diffRate: '0.082705606467', turnRate: '124.41560805', yearMon: '201806' }, { diffRate: '-0.029435972692', turnRate: '136.88809414', yearMon: '201807' }, { diffRate: '-0.034470873222', turnRate: '144.95967175', yearMon: '201808' }, { diffRate: '0.053269428440', turnRate: '131.08131251', yearMon: '201809' }, { diffRate: '0.031465463205', turnRate: '122.39787522', yearMon: '201810' }, { diffRate: '0.011804059927', turnRate: '126.68816773', yearMon: '201811' }, { diffRate: '-0.092148596422', turnRate: '114.43528144', yearMon: '201812' }
      ]
    }
  } else if (body.name && body.name === '百丽丝') {
    return {
      res: [
        { diffRate: '0.010015229307', turnRate: '121.99136422', yearMon: '201803' }, { diffRate: '-0.022072878996', turnRate: '113.52783249', yearMon: '201804' }, { diffRate: '0.031379863434', turnRate: '121.19264465', yearMon: '201805' }, { diffRate: '0.082705606467', turnRate: '124.41560805', yearMon: '201806' }, { diffRate: '-0.029435972692', turnRate: '136.88809414', yearMon: '201807' }, { diffRate: '-0.034470873222', turnRate: '144.95967175', yearMon: '201808' }, { diffRate: '0.053269428440', turnRate: '131.08131251', yearMon: '201809' }, { diffRate: '0.031465463205', turnRate: '122.39787522', yearMon: '201810' }, { diffRate: '0.011804059927', turnRate: '126.68816773', yearMon: '201811' }, { diffRate: '-0.092148596422', turnRate: '114.43528144', yearMon: '201812' }
      ]
    }
  } else if (body.name && body.name === '直营') {
    return {
      res: [
        { diffRate: '-0.007350994461', turnRate: '103.98839483', yearMon: '201801' }, { diffRate: '0.019804021564', turnRate: '144.82383852', yearMon: '201802' }, { diffRate: '0.010015229307', turnRate: '121.99136422', yearMon: '201803' }, { diffRate: '-0.022072878996', turnRate: '113.52783249', yearMon: '201804' }, { diffRate: '0.031379863434', turnRate: '121.19264465', yearMon: '201805' }, { diffRate: '0.082705606467', turnRate: '124.41560805', yearMon: '201806' }, { diffRate: '-0.029435972692', turnRate: '136.88809414', yearMon: '201807' }, { diffRate: '-0.034470873222', turnRate: '144.95967175', yearMon: '201808' }, { diffRate: '0.053269428440', turnRate: '131.08131251', yearMon: '201809' }, { diffRate: '0.031465463205', turnRate: '122.39787522', yearMon: '201810' }, { diffRate: '0.011804059927', turnRate: '126.68816773', yearMon: '201811' }
      ]
    }
  } else if (body.name && body.name === '大客户') {
    return {
      res: [
        { diffRate: '-0.007350994461', turnRate: '103.98839483', yearMon: '201801' }, { diffRate: '0.019804021564', turnRate: '144.82383852', yearMon: '201802' }, { diffRate: '0.010015229307', turnRate: '121.99136422', yearMon: '201803' }, { diffRate: '-0.022072878996', turnRate: '113.52783249', yearMon: '201804' }, { diffRate: '0.031379863434', turnRate: '121.19264465', yearMon: '201805' }, { diffRate: '0.082705606467', turnRate: '124.41560805', yearMon: '201806' }, { diffRate: '-0.029435972692', turnRate: '136.88809414', yearMon: '201807' }, { diffRate: '-0.034470873222', turnRate: '144.95967175', yearMon: '201808' }, { diffRate: '0.053269428440', turnRate: '131.08131251', yearMon: '201809' }, { diffRate: '0.031465463205', turnRate: '122.39787522', yearMon: '201810' }
      ]
    }
  } else {
    return {
      res: [
        { diffRate: '0.019804021564', turnRate: '144.82383852', yearMon: '201802' }, { diffRate: '0.010015229307', turnRate: '121.99136422', yearMon: '201803' }, { diffRate: '-0.022072878996', turnRate: '113.52783249', yearMon: '201804' }, { diffRate: '0.031379863434', turnRate: '121.19264465', yearMon: '201805' }, { diffRate: '0.082705606467', turnRate: '124.41560805', yearMon: '201806' }, { diffRate: '-0.029435972692', turnRate: '136.88809414', yearMon: '201807' }, { diffRate: '-0.034470873222', turnRate: '144.95967175', yearMon: '201808' }, { diffRate: '0.053269428440', turnRate: '131.08131251', yearMon: '201809' }, { diffRate: '0.031465463205', turnRate: '122.39787522', yearMon: '201810' }, { diffRate: '0.011804059927', turnRate: '126.68816773', yearMon: '201811' }
      ]
    }
  }
})

/**
 * @description sxjf/kckz_3 库存控制左下
 */
window.Mock.mock(/(sxjf\/kckz_3)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '数量') {
    return {
      res: [
        {examSub: '水星', amt: '512437189.45233200'}, {examSub: '电子商务', amt: '385000397.67052600'}, {examSub: '百丽丝', amt: '68461741.71844600'}, {examSub: '直营', amt: '59800775.81996000'}, {examSub: '大客户', amt: '8921801.35161600'}, {examSub: '外贸', amt: '291725.34483800'}
      ]
    }
  } else {
    return {
      res: [
        { examSub: '电子商务', amt: '3468797.05800000' }, { examSub: '水星', amt: '1778389.00000000' }, { examSub: '直营', amt: '944910.03200000' }, { examSub: '百丽丝', amt: '271178.00000000' }, { examSub: '大客户', amt: '55559.00000000' }, { examSub: '外贸', amt: '7990.00000000' }
      ]
    }
  }
})

/**
 * @description sxjf/kckz_4 库存控制右下
 */
window.Mock.mock(/(sxjf\/kckz_4)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '数量') {
    return {
      res: [
        { examSub: '水星', amt: '501968.00000000', type: '套件' }, { examSub: '电子商务', amt: '795675.00000000', type: '套件' }, { examSub: '百丽丝', amt: '99907.00000000', type: '套件' }, { examSub: '直营', amt: '72303.00000000', type: '套件' }, { examSub: '大客户', amt: '34160.00000000', type: '套件' }, { examSub: '外贸', amt: '302.00000000', type: '套件' }, { examSub: '水星', amt: '304948.00000000', type: '被芯' }, { examSub: '电子商务', amt: '441239.50000000', type: '被芯' }, { examSub: '百丽丝', amt: '38198.00000000', type: '被芯' }, { examSub: '直营', amt: '45959.00000000', type: '被芯' }, { examSub: '大客户', amt: '3702.00000000', type: '被芯' }, { examSub: '外贸', amt: '524.00000000', type: '被芯' }, { examSub: '水星', amt: '228087.00000000', type: '枕芯' }, { examSub: '电子商务', amt: '274056.00000000', type: '枕芯' }, { examSub: '百丽丝', amt: '31781.00000000', type: '枕芯' }, { examSub: '直营', amt: '41107.00000000', type: '枕芯' }, { examSub: '大客户', amt: '3816.00000000', type: '枕芯' }, { examSub: '外贸', amt: '3133.00000000', type: '枕芯' }, { examSub: '水星', amt: '157322.00000000', type: '家居' }, { examSub: '电子商务', amt: '210882.00000000', type: '家居' }, { examSub: '百丽丝', amt: '9915.00000000', type: '家居' }, { examSub: '直营', amt: '24698.00000000', type: '家居' }, { examSub: '大客户', amt: '1911.00000000', type: '家居' }, { examSub: '外贸', amt: '0.00000000', type: '家居' }, { examSub: '水星', amt: '94492.00000000', type: '夏被' }, { examSub: '电子商务', amt: '97386.00000000', type: '夏被' }, { examSub: '百丽丝', amt: '15695.00000000', type: '夏被' }, { examSub: '直营', amt: '6821.00000000', type: '夏被' }, { examSub: '大客户', amt: '994.00000000', type: '夏被' }, { examSub: '外贸', amt: '0.00000000', type: '夏被' }, { examSub: '水星', amt: '101789.00000000', type: '毛毯' }, { examSub: '电子商务', amt: '78753.00000000', type: '毛毯' }, { examSub: '百丽丝', amt: '8644.00000000', type: '毛毯' }, { examSub: '直营', amt: '7562.00000000', type: '毛毯' }, { examSub: '大客户', amt: '3542.00000000', type: '毛毯' }, { examSub: '外贸', amt: '3.00000000', type: '毛毯' }, { examSub: '水星', amt: '134.00000000', type: '婴童用品' }, { examSub: '电子商务', amt: '151870.00000000', type: '婴童用品' }, { examSub: '直营', amt: '266.00000000', type: '婴童用品' }, { examSub: '水星', amt: '16859.00000000', type: '凉席' }, { examSub: '电子商务', amt: '118309.00000000', type: '凉席' }, { examSub: '百丽丝', amt: '6139.00000000', type: '凉席' }, { examSub: '直营', amt: '4046.00000000', type: '凉席' }, { examSub: '大客户', amt: '5658.00000000', type: '凉席' }, { examSub: '外贸', amt: '0.00000000', type: '凉席' }, { examSub: '水星', amt: '78537.00000000', type: '单件' }, { examSub: '电子商务', amt: '37235.00000000', type: '单件' }, { examSub: '百丽丝', amt: '10711.00000000', type: '单件' }, { examSub: '直营', amt: '5197.00000000', type: '单件' }, { examSub: '大客户', amt: '1775.00000000', type: '单件' }, { examSub: '外贸', amt: '3912.00000000', type: '单件' }, { examSub: '水星', amt: '96456.00000000', type: '软装' }, { examSub: '电子商务', amt: '0.00000000', type: '软装' }, { examSub: '百丽丝', amt: '0.00000000', type: '软装' }, { examSub: '直营', amt: '1479.00000000', type: '软装' }, { examSub: '水星', amt: '43699.00000000', type: '床垫' }, { examSub: '电子商务', amt: '45724.00000000', type: '床垫' }, { examSub: '百丽丝', amt: '4174.00000000', type: '床垫' }, { examSub: '直营', amt: '4070.00000000', type: '床垫' }, { examSub: '大客户', amt: '0.00000000', type: '床垫' }, { examSub: '外贸', amt: '116.00000000', type: '床垫' }, { examSub: '水星', amt: '302.00000000', type: '蚊帐' }, { examSub: '电子商务', amt: '14068.00000000', type: '蚊帐' }, { examSub: '百丽丝', amt: '1891.00000000', type: '蚊帐' }, { examSub: '直营', amt: '95.00000000', type: '蚊帐' }, { examSub: '大客户', amt: '1.00000000', type: '蚊帐' }
      ]
    }
  } else {
    return {
      res: [
        {examSub: '水星', amt: '239158379.04081300', type: '套件'}, {examSub: '电子商务', amt: '201541745.00000000', type: '套件'}, {examSub: '百丽丝', amt: '43779177.43533600', type: '套件'}, {examSub: '直营', amt: '30463396.24219500', type: '套件'}, {examSub: '大客户', amt: '6326587.35161600', type: '套件'}, {examSub: '外贸', amt: '117360.57403400', type: '套件'}, {examSub: '水星', amt: '178396451.62723900', type: '被芯'}, {examSub: '电子商务', amt: '100757716.07140900', type: '被芯'}, {examSub: '百丽丝', amt: '15575656.11769000', type: '被芯'}, {examSub: '直营', amt: '20091728.82696000', type: '被芯'}, {examSub: '大客户', amt: '1109594.00000000', type: '被芯'}, {examSub: '外贸', amt: '73059.66684800', type: '被芯'}, {examSub: '水星', amt: '24483693.51471400', type: '夏被'}, {examSub: '电子商务', amt: '13182544.98637600', type: '夏被'}, {examSub: '百丽丝', amt: '3242329.00000000', type: '夏被'}, {examSub: '直营', amt: '907643.00000000', type: '夏被'}, {examSub: '大客户', amt: '97981.00000000', type: '夏被'}, {examSub: '外贸', amt: '0.00000000', type: '夏被'}, {examSub: '水星', amt: '15584629.00000000', type: '凉席'}, {examSub: '电子商务', amt: '18476906.00000000', type: '凉席'}, {examSub: '百丽丝', amt: '938411.00000000', type: '凉席'}, {examSub: '直营', amt: '996284.00000000', type: '凉席'}, {examSub: '大客户', amt: '624939.00000000', type: '凉席'}, {examSub: '外贸', amt: '0.00000000', type: '凉席'}, {examSub: '水星', amt: '10795862.07427200', type: '枕芯'}, {examSub: '电子商务', amt: '16884168.15000000', type: '枕芯'}, {examSub: '百丽丝', amt: '1669170.00000000', type: '枕芯'}, {examSub: '直营', amt: '2619276.42355300', type: '枕芯'}, {examSub: '大客户', amt: '385442.00000000', type: '枕芯'}, {examSub: '外贸', amt: '46494.52383400', type: '枕芯'}, {examSub: '水星', amt: '11631552.00000000', type: '毛毯'}, {examSub: '电子商务', amt: '6751115.00000000', type: '毛毯'}, {examSub: '百丽丝', amt: '931871.00000000', type: '毛毯'}, {examSub: '直营', amt: '652818.00000000', type: '毛毯'}, {examSub: '大客户', amt: '236012.00000000', type: '毛毯'}, {examSub: '外贸', amt: '554.00000000', type: '毛毯'}, {examSub: '水星', amt: '10329698.75134700', type: '床垫'}, {examSub: '电子商务', amt: '6914958.60000000', type: '床垫'}, {examSub: '百丽丝', amt: '631814.00000000', type: '床垫'}, {examSub: '直营', amt: '750695.40000000', type: '床垫'}, {examSub: '大客户', amt: '0.00000000', type: '床垫'}, {examSub: '外贸', amt: '3782.45886200', type: '床垫'}, {examSub: '水星', amt: '5615648.50263200', type: '家居'}, {examSub: '电子商务', amt: '3942104.90712800', type: '家居'}, {examSub: '百丽丝', amt: '229919.00000000', type: '家居'}, {examSub: '直营', amt: '531276.31000000', type: '家居'}, {examSub: '大客户', amt: '83534.00000000', type: '家居'}, {examSub: '外贸', amt: '56.46047200', type: '家居'}, {examSub: '水星', amt: '8835616.21000000', type: '软装'}, {examSub: '电子商务', amt: '0.00000000', type: '软装'}, {examSub: '百丽丝', amt: '0.00000000', type: '软装'}, {examSub: '直营', amt: '1116616.10000000', type: '软装'}, {examSub: '水星', amt: '4785930.84705900', type: '单件'}, {examSub: '电子商务', amt: '3456689.55724100', type: '单件'}, {examSub: '百丽丝', amt: '802206.33830900', type: '单件'}, {examSub: '直营', amt: '251891.26875000', type: '单件'}, {examSub: '大客户', amt: '57712.00000000', type: '单件'}, {examSub: '外贸', amt: '50099.93078800', type: '单件'}, {examSub: '水星', amt: '27571.40000000', type: '婴童用品'}, {examSub: '电子商务', amt: '8427328.31000000', type: '婴童用品'}, {examSub: '直营', amt: '20111.20000000', type: '婴童用品'}, {examSub: '水星', amt: '71733.00000000', type: '蚊帐'}, {examSub: '电子商务', amt: '2741644.40000000', type: '蚊帐'}, {examSub: '百丽丝', amt: '363859.00000000', type: '蚊帐'}, {examSub: '直营', amt: '12347.00000000', type: '蚊帐'}, {examSub: '大客户', amt: '0.00000000', type: '蚊帐'}, {examSub: '水星', amt: '914540.35167400', type: '半成品'}, {examSub: '电子商务', amt: '1035.44974600', type: '半成品'}, {examSub: '百丽丝', amt: '0.00000000', type: '半成品'}, {examSub: '直营', amt: '354411.99000000', type: '半成品'}, {examSub: '外贸', amt: '0.00000000', type: '半成品'}
      ]
    }
  }
})

/**
 * @description sxjf/xsck_1 销售出库分析左上
 */
window.Mock.mock(/(sxjf\/xsck_1)$/, options => {
  return {
    res: [
      { examSub: '电子商务', performRate: '0.682985690000' }, { examSub: '水星', performRate: '0.480569390000' }, { examSub: '百丽丝', performRate: '0.394434340000' }
    ]
  }
})

/**
 * @description sxjf/xsck_2 销售出库分析右上
 */
window.Mock.mock(/(sxjf\/xsck_2)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '电子商务') {
    return {
      res: [
        { planQty: '1896671.00000000', yearMon: '201810', actualQty: '914846.00000000', performRate: '0.386584200000' },
        { planQty: '2452260.00000000', yearMon: '201811', actualQty: '1852901.00000000', performRate: '0.543063326667' },
        { planQty: '1790783.00000000', yearMon: '201812', actualQty: '1712589.00000000', performRate: '0.519329806667' }
      ]
    }
  } else if (body.name && body.name === '水星') {
    return {
      res: [
        { planQty: '1296671', yearMon: '201810', actualQty: '614846', performRate: '0.286584200000' },
        { planQty: '1452260', yearMon: '201811', actualQty: '2852901', performRate: '0.343063326667' },
        { planQty: '2790783', yearMon: '201812', actualQty: '1012589', performRate: '0.719329806667' }
      ]
    }
  } else if (body.name && body.name === '百丽丝') {
    return {
      res: [
        { planQty: '2296671', yearMon: '201810', actualQty: '414846', performRate: '0.386584200000' },
        { planQty: '3452260', yearMon: '201811', actualQty: '1852901', performRate: '0.643063326667' },
        { planQty: '1790783', yearMon: '201812', actualQty: '812589', performRate: '0.419329806667' }
      ]
    }
  } else {
    return {
      res: [
        { planQty: '3296671', yearMon: '201810', actualQty: '714846', performRate: '0.586584200000' },
        { planQty: '4452260', yearMon: '201811', actualQty: '2852901', performRate: '0.743063326667' },
        { planQty: '3290783', yearMon: '201812', actualQty: '2812589', performRate: '0.619329806667' }
      ]
    }
  }
})

/**
 * @description sxjf/xsck_3 销售出库分析左下
 */
window.Mock.mock(/(sxjf\/xsck_3)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '电子商务') {
    return {
      res: [
        { examSub: '电子商务', yearMon: '201810', accuracy: '0.2439' },
        { examSub: '电子商务', yearMon: '201811', accuracy: '0.3877' },
        { examSub: '电子商务', yearMon: '201812', accuracy: '0.4011' }
      ]
    }
  } else if (body.name && body.name === '水星') {
    return {
      res: [
        { examSub: '水星', yearMon: '201810', accuracy: '0.5183' },
        { examSub: '水星', yearMon: '201811', accuracy: '0.5400' },
        { examSub: '水星', yearMon: '201812', accuracy: '0.4007' }
      ]
    }
  } else if (body.name && body.name === '百丽丝') {
    return {
      res: [
        { examSub: '百丽丝', yearMon: '201810', accuracy: '0.1542' },
        { examSub: '百丽丝', yearMon: '201811', accuracy: '0.3584' },
        { examSub: '百丽丝', yearMon: '201812', accuracy: '0.3467' }
      ]
    }
  } else {
    return {
      res: [
        { examSub: '水星', yearMon: '201810', accuracy: '0.5183' },
        { examSub: '电子商务', yearMon: '201810', accuracy: '0.2439' },
        { examSub: '百丽丝', yearMon: '201810', accuracy: '0.1542' },
        { examSub: '水星', yearMon: '201811', accuracy: '0.5400' },
        { examSub: '电子商务', yearMon: '201811', accuracy: '0.3877' },
        { examSub: '百丽丝', yearMon: '201811', accuracy: '0.3584' },
        { examSub: '水星', yearMon: '201812', accuracy: '0.4007' },
        { examSub: '电子商务', yearMon: '201812', accuracy: '0.4011' },
        { examSub: '百丽丝', yearMon: '201812', accuracy: '0.3467' }
      ]
    }
  }
})

/**
 * @description sxjf/xsck_4 销售出库分析右下
 */
window.Mock.mock(/(sxjf\/xsck_4)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '电子商务') {
    return {
      res: [
        { examSub: '电子商务', yearMon: '201811', mtdQtyRate: '1.703155080000' },
        { examSub: '电子商务', yearMon: '201812', mtdQtyRate: '1.132424440000' }
      ]
    }
  } else if (body.name && body.name === '水星') {
    return {
      res: [
        { examSub: '水星', yearMon: '201811', mtdQtyRate: '0.509803570000' },
        { examSub: '水星', yearMon: '201812', mtdQtyRate: '0.543492930000' }
      ]
    }
  } else if (body.name && body.name === '百丽丝') {
    return {
      res: [
        { examSub: '百丽丝', yearMon: '201811', mtdQtyRate: '1.930523870000' },
        { examSub: '百丽丝', yearMon: '201812', mtdQtyRate: '0.436846490000' }
      ]
    }
  } else {
    return {
      res: [
        { examSub: '水星', yearMon: '201811', mtdQtyRate: '0.509803570000' },
        { examSub: '电子商务', yearMon: '201811', mtdQtyRate: '1.703155080000' },
        { examSub: '百丽丝', yearMon: '201811', mtdQtyRate: '1.930523870000' },
        { examSub: '水星', yearMon: '201812', mtdQtyRate: '0.543492930000' },
        { examSub: '电子商务', yearMon: '201812', mtdQtyRate: '1.132424440000' },
        { examSub: '百丽丝', yearMon: '201812', mtdQtyRate: '0.436846490000' }
      ]
    }
  }
})

/**
 * @description 计划入库 左
 */
window.Mock.mock(/(sxjf\/jhrk_1)$/, options => {
  return {
    res: [
      {examSub: '外贸', performRate: '0.373981850000'},
      {examSub: '大客户', performRate: '0.193099900000'},
      {examSub: '百丽丝', performRate: '0.190019270000'},
      {examSub: '电子商务', performRate: '0.173537370000'},
      {examSub: '水星', performRate: '0.151773320000'}
    ]
  }
})

/**
 * @description 计划入库 右上
 */
window.Mock.mock(/(sxjf\/jhrk_2)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '外贸') {
    return {
      res: [
        {performQty: '196961.00000000', invQty: '1636656.00000000', yearMon: '201809', performRate: '0.116482342000'},
        {performQty: '296961.00000000', invQty: '2636656.00000000', yearMon: '201810', performRate: '0.226482342000'},
        {performQty: '396961.00000000', invQty: '3636656.00000000', yearMon: '201811', performRate: '0.136482342000'}
      ]
    }
  } else if (body.name && body.name === '大客户') {
    return {
      res: [
        {performQty: '126961.00000000', invQty: '1636656.00000000', yearMon: '201809', performRate: '0.086482342000'},
        {performQty: '326961.00000000', invQty: '2636656.00000000', yearMon: '201810', performRate: '0.126482342000'},
        {performQty: '296961.00000000', invQty: '3636656.00000000', yearMon: '201811', performRate: '0.096482342000'}
      ]
    }
  } else if (body.name && body.name === '百丽丝') {
    return {
      res: [
        {performQty: '146961.00000000', invQty: '1636656.00000000', yearMon: '201809', performRate: '0.136482342000'},
        {performQty: '156961.00000000', invQty: '2636656.00000000', yearMon: '201810', performRate: '0.116482342000'},
        {performQty: '166961.00000000', invQty: '3636656.00000000', yearMon: '201811', performRate: '0.06482342000'}
      ]
    }
  } else if (body.name && body.name === '电子商务') {
    return {
      res: [
        {performQty: '296961.00000000', invQty: '1636656.00000000', yearMon: '201809', performRate: '0.156482342000'},
        {performQty: '396961.00000000', invQty: '2636656.00000000', yearMon: '201810', performRate: '0.216482342000'},
        {performQty: '496961.00000000', invQty: '3636656.00000000', yearMon: '201811', performRate: '0.356482342000'}
      ]
    }
  } else if (body.name && body.name === '水星') {
    return {
      res: [
        {performQty: '196961.00000000', invQty: '1636656.00000000', yearMon: '201809', performRate: '0.116482342000'},
        {performQty: '296961.00000000', invQty: '2636656.00000000', yearMon: '201810', performRate: '0.146482342000'},
        {performQty: '396961.00000000', invQty: '3636656.00000000', yearMon: '201811', performRate: '0.216482342000'}
      ]
    }
  } else {
    return {
      res: [
        {performQty: '596961.00000000', invQty: '4636656.00000000', yearMon: '201809', performRate: '0.216482342000'},
        {performQty: '696961.00000000', invQty: '5636656.00000000', yearMon: '201810', performRate: '0.316482342000'},
        {performQty: '796961.00000000', invQty: '8636656.00000000', yearMon: '201811', performRate: '0.416482342000'}
      ]
    }
  }
})

/**
 * @description 计划入库 右下
 */
window.Mock.mock(/(sxjf\/jhrk_3)$/, options => {
  let body = JSON.parse(options.body)
  if (body.name && body.name === '外贸') {
    return {
      res: [
        {rate: '0.748882636667', yearMon: '201811'},
        {rate: '0.948882636667', yearMon: '201812'}
      ]
    }
  } else if (body.name && body.name === '大客户') {
    return {
      res: [
        {rate: '0.548882636667', yearMon: '201811'},
        {rate: '0.648882636667', yearMon: '201812'}
      ]
    }
  } else if (body.name && body.name === '百丽丝') {
    return {
      res: [
        {rate: '0.448882636667', yearMon: '201811'},
        {rate: '0.548882636667', yearMon: '201812'}
      ]
    }
  } else if (body.name && body.name === '电子商务') {
    return {
      res: [
        {rate: '0.518882636667', yearMon: '201811'},
        {rate: '0.764882636667', yearMon: '201812'}
      ]
    }
  } else if (body.name && body.name === '水星') {
    return {
      res: [
        {rate: '0.668882636667', yearMon: '201811'},
        {rate: '0.468882636667', yearMon: '201812'}
      ]
    }
  } else {
    return {
      res: [
        {rate: '0.678882636667', yearMon: '201811'},
        {rate: '0.878882636667', yearMon: '201812'}
      ]
    }
  }
})

/**
 * @description 采购入库 左
 */
window.Mock.mock(/(sxjf\/cgrk_1)$/, options => {
  return {
    res: [
      {examSub: '外贸', performRate: '0.373981850000'},
      {examSub: '大客户', performRate: '0.193099900000'},
      {examSub: '百丽丝', performRate: '0.190019270000'},
      {examSub: '电子商务', performRate: '0.173537370000'},
      {examSub: '水星', performRate: '0.151773320000'}
    ]
  }
})

/**
 * @description 生产入库 左
 */
window.Mock.mock(/(sxjf\/scrk_1)$/, options => {
  return {
    res: [
      {examSub: '外贸', performRate: '0.995000000000'},
      {examSub: '水星', performRate: '0.610326606416'},
      {examSub: '电子商务', performRate: '0.606683802111'},
      {examSub: '大客户', performRate: '0.285333333333'},
      {examSub: '百丽丝', performRate: '0.268417142800'}
    ]
  }
})

/**
 * @description 生产入库 右
 */
window.Mock.mock(/(sxjf\/jhrk_3)$/, options => {
  var arr = [
    {ontimeRate: 0.131935714915, factory: '委外', yearMon: '201901'},
    {ontimeRate: 0.173451160926, factory: '委外', yearMon: '201902'},
    {ontimeRate: 0.100646551724, factory: '委外', yearMon: '201903'}
  ]
  var value1 = 0
  var value2 = 0
  let body = JSON.parse(options.body)
  if (body.name1 && body.name2) {
    switch (body.name1) {
      case '水星':
        value1 = 0.1
        break
      case '大客户':
        value1 = 0.2
        break
      case '百丽丝':
        value1 = 0.3
        break
      case '电子商务':
        value1 = 0.4
        break
      case '外贸':
        value1 = 0.5
        break
    }
    switch (body.name2) {
      case '套件':
        value2 = 0.15
        break
      case '枕芯':
        value2 = 0.22
        break
      case '被芯':
        value2 = 0.27
        break
      case '委外':
        value2 = 0.32
        break
    }
    for (let i = 0; i < arr.length; i++) {
      arr[i].ontimeRate = arr[i].ontimeRate + value1 + value2
    }
  }
  return {
    res: arr
  }
})

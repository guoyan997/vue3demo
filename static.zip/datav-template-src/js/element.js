
// 注意这里的路径是相对于main.js
define([
  'lib/axios.min.js',
  'lib/vue.js',
  'lib/vue-jsonp.umd.js'
], function (
  axios,
  Vue,
  VueJsonp
) {
  // If you want to setup the global timeout, just:
  Vue.use(VueJsonp, 5000)

  /**
   * @description 对象序列化
   * @param {Object} obj 参数对象 {name:'hehe',age:10}
   * @return {String} name=hehe&age=10
   */
  function params2str (obj) {
    if (obj !== {}) {
      let str = ''
      for (let key in obj) {
        str += key + '=' + obj[key] + '&'
      }
      str = str.slice(0, str.length - 1)
      return str
    } else {
      return ''
    }
  }

  /**
 * @description 请求数据
 * @param {String} url 接口地址
 * @param {String} method 请求方法
 * @param {[Object]} params 请求参数
 * @param {String} type 接口类型 cas / normal
 */
  const request = (url, method, params, type) => {
    try {
      let httpPatt = /^(http:\/\/)/ // 匹配字段以http://开头
      let httpsPatt = /^(https:\/\/)/ // 匹配字段以https://开头

      let platformUrl // platformUrl: host + 'InterfacePlatform/validate/TestCall' // 连接接口平台
      if (httpPatt.test(url)) {
        let a = url.slice(7).indexOf('/')
        // http://10.73.14.103:8080
        platformUrl = url.slice(0, 7 + a) + '/InterfacePlatform/validate/TestCall'
      } else if (httpsPatt.test(url)) {
        let a = url.slice(8).indexOf('/')
        // https://10.73.14.103:8080
        platformUrl = url.slice(0, 7 + a) + '/InterfacePlatform/validate/TestCall'
      } else {
        // url不以http开头
      }

      const postData = {}
      const requestConfig = {
        method: method
      }
      // get请求，拼接参数
      if (method === 'get' || method === 'GET') {
        if (url.indexOf('?') < 0) {
          url += '?'
        }
        for (let param of params) {
          url += `${param.name}=${param.value}&`
        }
      }
      // post请求，构造请求数据
      if (method === 'post' || method === 'POST') {
        for (let param of params) {
          postData[param.name] = param.value
        }
      }
      requestConfig.url = url
      requestConfig.data = postData

      window.runDebugger && console.log('type=', type)
      // 连通接口平台
      if (platformUrl && type === 'cas') {
        window.runDebugger && console.log('platformUrl=', platformUrl)
        // platformUrl = 'http://10.18.35.180:8087/InterfacePlatform/validate/TestCall' // 测试
        let casPromise = new Promise(function (resolve, reject) {
          let errCount = 0 // 接口平台错误计数
          function jsonpRequest () {
            Vue.jsonp(platformUrl).then(res => {
              window.runDebugger && console.log('连接接口平台成功res =', res)
              window.runDebugger && console.log('连接接口平台成功res.data =', res.data)
              requestConfig.headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
              }
              requestConfig.withCredentials = true // 携带凭证
              // 参数序列化
              requestConfig.data = params2str(postData)
              window.runDebugger && console.log('requestConfig.data=', requestConfig.data)
              if (res.data) {
                axios(requestConfig).then(resolve).catch(reject)
              } else {
                if (errCount < 3) {
                  errCount++
                  jsonpRequest()
                } else {
                  axios(requestConfig).then(resolve).catch(reject)
                }
              }
            }).catch(error => {
              window.runDebugger && console.log('连接接口平台失败')
              window.runDebugger && console.log('error=', error)
              window.runDebugger && console.log('errCount=', errCount)
              if (errCount < 3) {
                // reject()
                errCount++
                jsonpRequest()
                // axios(requestConfig).then(resolve).catch(reject)
              } else {
                // resolve()
                axios(requestConfig).then(resolve).catch(reject)
              }
            })
          }
          jsonpRequest()
        })
        return casPromise
      } else {
        window.runDebugger && console.log('platformUrl=', platformUrl)
        window.runDebugger && console.log('type=', type)
        return axios(requestConfig)
      }
    } catch (error) {
      throw error
    }
  }

  return request
})

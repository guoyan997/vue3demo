/**
 * 通用基础图表配置
 * 数字类型要用String：60 - '60'，
 * 不然autoComplete组件会报错，类型不匹配
 */

// BasicCommonOption

define([], function () {
  return {
    color: [],
    backgroundColor: 'rgba(255, 255, 255, 0)',
    title: {
      show: true, // 是否显示标题
      text: '', // 主标题
      textStyle: {
        color: '#333',
        fontSize: 12
      },
      subtext: '',
      subtextStyle: {
        color: '#aaa',
        fontSize: 12
      },
      top: 'auto',
      bottom: 'auto',
      left: 'auto',
      right: 'auto'
    },
    legend: {
      left: 'auto',
      top: 'auto',
      right: 'auto',
      bottom: 'auto',
      orient: 'horizontal',
      show: true,
      textStyle: {
        fontSize: 12,
        color: '#333'
      },
      itemGap: 10
    },
    grid: {
      show: false,
      backgroundColor: 'rgba(255, 255, 255, 0)',
      top: '60',
      bottom: '60',
      left: '10%',
      right: '10%'
    },
    tooltip: {
      show: true,
      trigger: 'item',
      axisPointer: {
        type: 'line',
        lineStyle: {
          color: '#555',
          width: 1,
          type: 'solid'
        },
        shadowStyle: {
          color: 'rgba(150,150,150,0.3)',
          shadowBlur: 10
        },
        crossStyle: {
          color: '#555',
          width: 1,
          type: 'dashed'
        }
      },
      backgroundColor: 'rgba(50,50,50,0.7)',
      borderColor: '#333',
      borderWidth: 0,
      textStyle: {
        color: '#fff',
        fontSize: 14
      },
      formatter: ''
    },
    series: []
  }
})

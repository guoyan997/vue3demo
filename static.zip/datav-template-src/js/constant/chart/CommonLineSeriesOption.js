/**
 * 通用线图系列配置
 */
// CommonLineSeriesOption

define([], function () {
  return {
    type: 'line',
    yAxisIndex: 0,
    symbol: 'emptyCircle',
    symbolSize: 4,
    smooth: false,
    label: {
      normal: {
        show: false,
        position: 'top',
        distance: 5,
        fontSize: 12,
        color: '#ffffff'
      }
    },
    lineStyle: {
      // 不允许配置线条颜色，由系列决定，合并主题逻辑困难
      // color: '',
      width: 2
    },
    areaStyle: {
      opacity: 0,
      color: ''
    }
  }
})

/**
 * 通用坐标轴配置
 */

// BasicCommonAxisOption

define([], function () {
  return {
    xAxis: [{
      show: true,
      type: 'category',
      name: '',
      nameLocation: 'end',
      nameTextStyle: {
        // 坐标轴名称的颜色，默认取 axisLine.lineStyle.color
        color: '#333',
        fontSize: 12
      },
      nameGap: 15,
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true,
        // 刻度线的颜色，默认取 axisLine.lineStyle.color
        lineStyle: {
          color: '#333'
        }
      },
      axisLabel: {
        show: true,
        textStyle: {
          // 刻度标签文字的颜色，默认取 axisLine.lineStyle.color
          color: '#333'
        },
        fontSize: 12,
        rotate: 0,
        // 标签格式
        formatter: '{value}'
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: ['#ccc'],
          width: 1
        }
      },
      splitArea: {
        show: false,
        areaStyle: {
          color: ['rgba(250,250,250,0.3)', 'rgba(200,200,200,0.3)']
        }
      }
    }],
    yAxis: [
      {
        show: true,
        type: 'value',
        name: '',
        nameLocation: 'end',
        nameTextStyle: {
          // 坐标轴名称的颜色，默认取 axisLine.lineStyle.color
          color: '#333',
          fontSize: 12
        },
        nameGap: 15,
        // 分割段数
        splitNumber: 5,
        axisLine: {
          show: true,
          lineStyle: {
            color: '#333',
            width: 1
          }
        },
        axisTick: {
          show: true,
          // 刻度线的颜色，默认取 axisLine.lineStyle.color
          lineStyle: {
            color: '#333'
          }
        },
        axisLabel: {
          show: true,
          textStyle: {
            // 刻度标签文字的颜色，默认取 axisLine.lineStyle.color
            color: '#333'
          },
          fontSize: 12,
          rotate: 0,
          // 标签格式
          formatter: '{value}'
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#ccc'],
            width: 1
          }
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ['rgba(250,250,250,0.3)', 'rgba(200,200,200,0.3)']
          }
        }
      },
      {
        show: false,
        type: 'value',
        name: '',
        nameLocation: 'end',
        nameTextStyle: {
          // 坐标轴名称的颜色，默认取 axisLine.lineStyle.color
          color: '#333',
          fontSize: 12
        },
        nameGap: 15,
        // 分割段数
        splitNumber: 5,
        axisLine: {
          show: true,
          lineStyle: {
            color: '#333',
            width: 1
          }
        },
        axisTick: {
          show: true,
          // 刻度线的颜色，默认取 axisLine.lineStyle.color
          lineStyle: {
            color: '#333'
          }
        },
        axisLabel: {
          show: true,
          textStyle: {
            // 刻度标签文字的颜色，默认取 axisLine.lineStyle.color
            color: '#333'
          },
          fontSize: 12,
          rotate: 0,
          // 标签格式
          formatter: '{value}'
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#ccc'],
            width: 1
          }
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ['rgba(250,250,250,0.3)', 'rgba(200,200,200,0.3)']
          }
        }
      }
    ]
  }
})

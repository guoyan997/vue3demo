/**
 * 通用柱状图系列配置
 */
// CommonBarSeriesOption

define([], function () {
  return {
    type: 'bar',
    yAxisIndex: 0,
    label: {
      normal: {
        show: false,
        position: 'inside',
        distance: 5,
        fontSize: 12,
        color: '#ffffff'
      }
    },
    barWidth: 'auto',
    barGap: '30%'
  }
})

/**
 * @description 系统页面事件
 */

// PageEvent

define([], function () {
  return {
    // 改变页面状态变量
    CHANGE_PAGE_STATE: 'CHANGE_PAGE_STATE',
    // 改变作品状态变量
    CHANGE_WORK_STATE: 'CHANGE_WORK_STATE'
  }
})

/**
 * @description 系统作品事件
 */

// WorkEvent

define([], function () {
  return {
    // 窗口变化
    'WINDOW_RESIZE': 'WINDOW_RESIZE'
  }
})

/**
 * @description 系统常量
 */
// 注意这里的路径是相对于main.js
define([
  'js/constant/PageEvent.js',
  'js/constant/WorkEvent.js',
  'js/constant/BasicCommonOption.js',
  'js/constant/chart/BasicCommonAxisOption.js',
  'js/constant/chart/CommonLineSeriesOption.js',
  'js/constant/chart/CommonBarSeriesOption.js',
  'js/constant/CommonSeriesOption.js'
], function (
  PageEvent,
  WorkEvent,
  BasicCommonOption,
  BasicCommonAxisOption,
  CommonLineSeriesOption,
  CommonBarSeriesOption,
  CommonSeriesOption
) {
  const SYS_EVENT = {
    // 窗口调整大小
    RESIZE_WINDOW: 'RESIZE_WINDOW',
    // 重新渲染页面
    RERENDER_PAGE: 'RERENDER_PAGE',
    // 重新渲染图表
    RERENDER_CHART: 'RERENDER_CHART',
    // 图表调整大小
    RESIZE_CHART: 'RESIZE_CHART',
    // 显示资源列表
    SHOW_RESOURCE_LIST: 'SHOW_RESOURCE_LIST',
    // 绑定图表事件
    BIND_CHART_EVENT: 'BIND_CHART_EVENT',
    // 选择资源
    CHOOSE_RESOURCE: 'CHOOSE_RESOURCE'
  }

  return {
    BasicCommonOption: BasicCommonOption,
    BasicCommonAxisOption: BasicCommonAxisOption,
    PAGE_EVENT: PageEvent,
    WORK_EVENT: WorkEvent,
    SYS_EVENT: SYS_EVENT,
    CommonLineSeriesOption: CommonLineSeriesOption,
    CommonBarSeriesOption: CommonBarSeriesOption,
    CommonSeriesOption: CommonSeriesOption
  }
})

/**
 * @description 系统常量
 */
// import ChartMockData from './ChartMockData'
// import BasicCommonOption from './BasicCommonOption'
// import CommonSeriesOption from './CommonSeriesOption'
// import EventList from './EventList'
// import EventTypeList from './EventTypeList'
// import PageEvent from './PageEvent'
// import StateType from './StateType'
// import ChartConstant from './chart'

// const constant = {
//   ChartMockData,
//   BasicCommonOption,
//   CommonSeriesOption,
//   EventList,
//   EventTypeList,
//   PageEvent,
//   StateType,
//   ChartConstant
// }

// /**
//  * 行业列表
//  */
// // const IndustryList = constant.IndustryList = [
// //   '通用',
// //   '制造',
// //   '汽车',
// //   '地产',
// //   '家纺',
// //   '化妆品'
// // ]

// /**
//  * 出场动画效果列表
//  */
// // const AnimateInList = constant.AnimateInList = [
// //   {
// //     name: '弹入',
// //     value: 'bounceIn'
// //   },
// //   {
// //     name: '淡入',
// //     value: 'fadeIn'
// //   },
// //   {
// //     name: '翻转',
// //     value: 'flip'
// //   },
// //   {
// //     name: '横向翻转',
// //     value: 'flipInX'
// //   },
// //   {
// //     name: '纵向翻转',
// //     value: 'flipInY'
// //   },
// //   {
// //     name: '回弹滑入',
// //     value: 'lightSpeedIn'
// //   },
// //   {
// //     name: '旋转',
// //     value: 'rotateIn'
// //   },
// //   {
// //     name: '上滑',
// //     value: 'slideInUp'
// //   },
// //   {
// //     name: '放大',
// //     value: 'zoomIn'
// //   }
// // ]

// /**
//  * 动画延时列表
//  */
// // const AnimateDelayList = constant.AnimateDelayList = [
// //   {
// //     name: '2s',
// //     value: 'delay-2s'
// //   },
// //   {
// //     name: '3s',
// //     value: 'delay-3s'
// //   },
// //   {
// //     name: '4s',
// //     value: 'delay-4s'
// //   },
// //   {
// //     name: '5s',
// //     value: 'delay-5s'
// //   }
// // ]

// /**
//  * 动画速度列表
//  */
// // const AnimateSpeedList = constant.AnimateSpeedList = [
// //   {
// //     name: '慢',
// //     value: 'slow'
// //   },
// //   {
// //     name: '较慢',
// //     value: 'slower'
// //   },
// //   {
// //     name: '较快',
// //     value: 'fast'
// //   },
// //   {
// //     name: '快',
// //     value: 'faster'
// //   }
// // ]

// /**
//  * @description 可视化平台编辑系统事件
//  */ // finished
// const SYS_EVENT = constant.SYS_EVENT = {
//   // 窗口调整大小
//   'RESIZE_WINDOW': 'RESIZE_WINDOW',
//   // 重新渲染页面
//   'RERENDER_PAGE': 'RERENDER_PAGE',
//   // 重新渲染图表
//   'RERENDER_CHART': 'RERENDER_CHART',
//   // 图表调整大小
//   'RESIZE_CHART': 'RESIZE_CHART',
//   // 显示资源列表
//   'SHOW_RESOURCE_LIST': 'SHOW_RESOURCE_LIST',
//   // 绑定图表事件
//   'BIND_CHART_EVENT': 'BIND_CHART_EVENT',
//   // 选择资源
//   'CHOOSE_RESOURCE': 'CHOOSE_RESOURCE'
// }

// /**
//  * @description 系统页面事件处理器
//  */
// const PAGE_EVENT_HANDLER = constant.PAGE_EVENT_HANDLER = {
//   /**
//    * @description 处理页面状态变量改变事件
//    * @param {Object} state 改变的状态变量，{String} name 状态名, {any} value 状态值
//    */
//   'CHANGE_PAGE_STATE': function ({name, value} = {}) {
//     try {
//       if (name && typeof name === 'string') {
//         localStorage.setItem(name, System.stringify(value))
//       }
//     } catch (error) {
//       console.error(`处理页面状态变量改变事件失败：${error}`)
//     }
//   }
// }

// /**
//  * @description 组件类型
//  */
// const COMPONENT_TYPE = constant.COMPONENT_TYPE = {
//   'ECHART': 'ECHART',
//   'PAGE': 'PAGE'
// }

// /**
//  * 组件编辑器
//  */
// // const ComponentEditors = constant.ComponentEditors = new Set([
// //   'TextEditor',
// //   'TableEditor',
// //   'BasicTableEditor',
// //   'BasicBarChartEditor',
// //   'BasicChinaMapEditor',
// //   'BasicLineChartEditor',
// //   'BasicPieChartEditor',
// //   'BasicScatterChartEditor',
// //   'BasicScatterMapEditor'
// // ])

// // 图表类型
// const CHART_TYPE_LIST = constant.CHART_TYPE_LIST = [
//   'line',
//   'radar', // 没markPoint
//   'bar',
//   'pie',
//   'scatter',
//   'boxplot',
//   'parallel',
//   'sankey',
//   'funnel', // 没markPoint
//   'gauge',
//   'candlestick',
//   'graph',
//   'map'
// ]

// export default constant

// export {
//   // IndustryList,
//   // AnimateInList,
//   // AnimateDelayList,
//   // AnimateSpeedList,
//   SYS_EVENT,
//   PageEvent,
//   PAGE_EVENT_HANDLER,
//   COMPONENT_TYPE,
//   // ComponentEditors,
//   CHART_TYPE_LIST,
//   ChartMockData,
//   BasicCommonOption,
//   CommonSeriesOption,
//   EventList,
//   EventTypeList,
//   StateType,
//   ChartConstant
// }

/**
 * 通用系列配置
 */
// CommonSeriesOption
define([], function () {
  return {
    label: {
      normal: {
        show: false,
        position: 'inside',
        distance: 5,
        fontSize: 12,
        color: '#ffffff'
      }
    }
  }
})

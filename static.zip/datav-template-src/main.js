/**
 * requirejs配置
 * https://github.com/requirejs/r.js/blob/master/build/example.build.js
 */
require.config({
  paths: {
    // Echarts路径
    'echarts': 'lib/echarts.min',
    'ELEMENT': 'lib/element-ui/lib/index',
    'vue': 'lib/vue'
  },
  shim: {
    // Echarts中国地图模块依赖Echarts
    'lib/china': {
      deps: ['echarts'],
      init: function (echarts) {
        window.Echarts = echarts
      }
    }
  },
  // 解决模块加载超时的问题
  waitSeconds: 0
})

/**
 * 当前的环境，区分是预览环境还是发布环境
 * dev - 预览
 * 其它 - 发布
 * gulp任务在编译模板时会自动把环境改成pro再复制到后台发布模板
 * 详见../gulpfile.js
 * runMode： dev 编辑模式 preview 预览模式 public 发布模式
 */
const env = 'dev'
if (env === 'dev') { // 编辑预览
  require([
    // 系统功能依赖
    'js/System.js'
  ], function (System) {
    // 预览模式从localStorage加载作品
    const work = localStorage.getItem('work')
    let startPageIndex = parseInt(localStorage.getItem('startPageIndex')) >= 0 ? parseInt(localStorage.getItem('startPageIndex')) : 0
    const runMode = 'preview'
    System.renderWork(work, startPageIndex, runMode)
  })
} else { // 发布
  require([
    // 系统功能依赖
    'js/System.js',
    // 作品代码
    'app/work.js'
  ], function (System, work) {
    const runMode = 'public'
    window.work = work // 暂时把work对象挂到window下，方便其他地方使用
    System.renderWork(work, 0, runMode)
  })
}
